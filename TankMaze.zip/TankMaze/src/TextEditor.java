import java.awt.*;
import java.util.ArrayList;

@SuppressWarnings("serial")
public class TextEditor extends Panel{
	private String editString = "";
	private boolean isShowing = false;
	public static ArrayList<TextEditor> textEditors = new ArrayList<TextEditor>();
	private Button done = new Button(new Rectangle(1280 / 2 - 50, 400 - 32, 100, 32), "Done", this);
	private Panel panel;
	private int max = 25;
	public TextEditor(Panel p){
		panel = p;
		textEditors.add(this);
	}
	public void showTextEditor(Graphics2D g2D){
		if(isShowing){
			g2D.setColor(new Color(255, 255, 255, 200));
			g2D.fillRect(1280 / 2 - 250, 720 / 2 - 150, 500, 200);
			g2D.setColor(new Color(0, 0, 0, 200));
			g2D.fillRect(1280 / 2 - 250 + 5, 720 / 2 - 150 + 5, 500 - 10, 200 - 10);
			g2D.setColor(new Color(0, 0, 0, 80));
			g2D.fillRect(1280 / 2 - 225,  720 / 2 - 14 - 52, 450, 20);
			g2D.setFont(new Font("sansserif", Font.BOLD, 32));
			g2D.setColor(Color.WHITE);
			drawCenteredString("Type to Change:", 720 / 2 - 100, g2D);
			g2D.setFont(new Font("sansserif", Font.BOLD, 16));
			drawCenteredString("(Max " + max + " Characters)", 720 / 2 - 75, g2D);
			g2D.setFont(new Font("sansserif", Font.BOLD, 18));
			drawCenteredString(editString, 720 / 2 - 50, g2D);
			int width = (int)(g2D.getFontMetrics().stringWidth(editString));
			g2D.drawLine(width / 2 + ((1280 / 2) + 5), 720 / 2 - 14 - 50, width / 2 + ((1280 / 2) + 5), 720 / 2 + 4 - 50);
			done.show();
			done.drawButton(g2D);
		}else{
			done.hide();
		}
	}
	public void drawCenteredString(String s, int y, Graphics2D g2D){
		int pos = (1280 / 2) - ((int)g2D.getFontMetrics().getStringBounds(s, g2D).getWidth() / 2);
		g2D.drawString(s, pos, y);
	}	
	public void setText(String s){
		editString = s;
	}
	public String getText(){
		return editString;
	}
	public void show(){
		isShowing = true;
	}
	public void close(){
		isShowing = false;
	}
	public boolean isShowing(){
		return isShowing;
	}
	public void performAction(Button b) {
		if(b.equals(done)){
			close();
			panel.repaint();
		}
	}
	public void setMax(int i){
		max = i;
	}
	public int getMax(){
		return max;
	}
}
