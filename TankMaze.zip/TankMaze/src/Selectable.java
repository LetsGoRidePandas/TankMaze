import java.awt.Rectangle;

public interface Selectable {
	public Rectangle getObjectBounds();
	public int getX();
	public int getY();
	public void setX(int newX);
	public void setY(int newY);
}
