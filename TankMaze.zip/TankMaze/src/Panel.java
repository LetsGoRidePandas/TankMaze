import javax.swing.JPanel;


@SuppressWarnings("serial")
public abstract class Panel extends JPanel implements ButtonManager{
	public abstract void performAction(Button b);

}
