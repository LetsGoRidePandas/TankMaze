import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import java.io.*;

@SuppressWarnings("serial")
public class LevelCustomizer extends Panel {
	Graphics2D g2D;
	public static int mouseX, mouseY;
	Button changeTitle = new Button(new Rectangle(10, 676, 100, 32), "Change Title", this);
	Button okay = new Button(new Rectangle(1280 / 2 - 50, 400 - 32, 100, 32), "Okay", this);
	Button saveLevel = new Button(new Rectangle(1280 - 110, 628, 100, 32), "Save Level", this);
	Button powerupTool = new Button(new Rectangle((1280 / 2) - 300, 628, 100, 32), "Add Powerup", this);
	Button selectionTool = new Button(new Rectangle((1280 / 2) + 110, 628, 100, 32), "Select", this);
	Button spawnTool = new Button(new Rectangle((1280 / 2) - 175, 628, 100, 32), "Spawn Point", this);
	Button wallTool = new Button(new Rectangle((1280 / 2) - 50, 628, 100, 32), "Draw Wall", this);
	Button enemyTool = new Button(new Rectangle((1280 / 2) - 300, 676, 100, 32), "Add Enemy", this);
	Button finishTool = new Button(new Rectangle((1280 / 2) - 175, 676, 100, 32), "Add Finish", this);
	Button textTool = new Button(new Rectangle((1280 / 2) - 50, 676, 100, 32), "Write Text", this);
	Button customLevels = new Button(new Rectangle((1280 - 110), 676, 100, 32), "Quit Editor", this);
	Button xChanger = new Button(new Rectangle((1280 / 2) + 310, 628, 50, 32), "...", this);
	Button yChanger = new Button(new Rectangle((1280 / 2) + 310, 676, 50, 32), "...", this);
	Button wChanger = new Button(new Rectangle((1280 / 2) + 370, 628, 50, 32), "...", this);
	Button hChanger = new Button(new Rectangle((1280 / 2) + 370, 676, 50, 32), "...", this);
	Button textChanger = new Button(new Rectangle((1280 / 2) + 110, 676, 100, 32), "...", this);
	public static double scaleX, scaleY, invScaleX, invScaleY;
	private static String fileName = "Untitled";
	static Image background = new ImageIcon(TankMazeGame.class.getResource("grass.png")).getImage();
	private boolean warningShown = false;
	private boolean savedShown = false;
	private boolean saved;
	private boolean dialogShowing = false;
	private static final int WALLMODE = 1, SPAWNMODE = 2, ENEMYMODE = 3, FINISHMODE = 4, POWERUPMODE = 5, TEXTMODE = 6, SELECTMODE = 7;
	private int toolMode = WALLMODE;
	private static final int SOLID = 1, BREAKABLE = 2;
	private int wallType = SOLID;
	private int powerupType = 1;
	private int enemyHealth = 50;
	private int spawnDirection = 0;
	private int textSize = 16;
	private String text = "Text";
	private int counter = 0;
	private Wall[] drawnWalls = new Wall[10000];
	private Powerup[] drawnPowerups = new Powerup[10000];
	private CPUTank[] drawnEnemies = new CPUTank[10000];
	private TextField[] drawnTextFields = new TextField[10000];
	private static int wallStartX, wallStartY;
	private Image[] cursors = {ImageLoader.cursor, ImageLoader.ammo, ImageLoader.boost, ImageLoader.fuel, ImageLoader.health, ImageLoader.finish};
	private Cursor[] cursor = new Cursor[6];
	private Selectable selectedObject = null;
	private TextEditor nameChanger = new TextEditor(this);
	private TextEditor xEditor = new TextEditor(this);
	private TextEditor yEditor = new TextEditor(this);
	private TextEditor wEditor = new TextEditor(this);
	private TextEditor hEditor = new TextEditor(this);
	private TextEditor textEditor = new TextEditor(this);
	private Button[] toolButtons ={changeTitle, saveLevel, powerupTool, selectionTool, spawnTool, wallTool, enemyTool, finishTool, textTool,
			customLevels, xChanger, yChanger, wChanger, hChanger, textChanger};

	public LevelCustomizer() {
		setBackground(Color.BLACK);
		scaleX = TankMazeRunner.WIDTH / 1280.0;
		scaleY = TankMazeRunner.WIDTH * 9.0 / 16.0 / 720.0;
		invScaleX = 1 / scaleX;
		invScaleY = 1 / scaleY;
		Level.loadLevel();
		fileName = Level.fileName;
		for (int i = 0; i < cursor.length; i++) {
			if (i > 0)
				cursor[i] = Toolkit.getDefaultToolkit().createCustomCursor(
						cursors[i], new Point(16, 16), "cursor");
			else
				cursor[i] = Toolkit.getDefaultToolkit().createCustomCursor(
						cursors[i], new Point(0, 0), "cursor");
		}
		setCursor(cursor[0]);
		nameChanger.setText(fileName);
		nameChanger.setMax(9);
		xEditor.setMax(4);
		yEditor.setMax(4);
		wEditor.setMax(4);
		hEditor.setMax(4);
		grabFocus();
		addKeyListener(new TypeListener());
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		setBackground(Color.BLACK);
		g2D = (Graphics2D) g;
		g2D.scale(scaleX, scaleY);
		g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2D.drawImage(background, 0, 0, null);
		Level.showLevel(g2D);
		moveObject();
		if(selectedObject instanceof ControlledTank){
			Level.spawnX = selectedObject.getX();
			Level.spawnY = selectedObject.getY();
			Level.spawnDirection = ((int)((ControlledTank)selectedObject).getDirection());
		}
		drawHUD(g2D);
		nameChanger.showTextEditor(g2D);
		xEditor.showTextEditor(g2D);
		yEditor.showTextEditor(g2D);
		wEditor.showTextEditor(g2D);
		hEditor.showTextEditor(g2D);
		textEditor.showTextEditor(g2D);
		if(textChanger.getText().equals("...")){
			textChanger.setFontSize(14);
		}
		fileName = nameChanger.getText();
		grabFocus();
		addMouseMotionListener(new CreateListener());
		addMouseWheelListener(new CreateListener());
		addMouseListener(new CreateListener());
	}
	public Rectangle2D getStringBounds(String text) {
		return g2D.getFontMetrics().getStringBounds(text, g2D);
	}

	public void drawCenteredString(String s, int y) {
		int pos = (1280 / 2) - ((int) g2D.getFontMetrics().getStringBounds(s, g2D).getWidth() / 2);
		g2D.drawString(s, pos, y);
	}

	public void drawHUD(Graphics2D g2D) {
		g2D.drawImage(ImageLoader.hud, 0, 600, null);
		Rectangle hudBar = new Rectangle(5, 605, 1280 - 10, 110);
		drawBorder(hudBar);
		g2D.setColor(new Color(255, 255, 255, 50));
		Rectangle tools = new Rectangle((1280 / 2) - 310, 605, 370, 110);
		g2D.fill(tools);
		drawBorder(tools);
		Rectangle properties = new Rectangle((1280 / 2) + 100, 605, 370, 110);
		g2D.setColor(new Color(255, 255, 255, 50));
		g2D.fill(properties);
		drawBorder(properties);
		g2D.setColor(Color.WHITE);
		g2D.setFont(new Font("sansserif", Font.BOLD, 18));
		g2D.drawString("-Tools-", (int) ((spawnTool.getRect().x + 50) - (getStringBounds("-Tools-").getWidth() / 2)), 622);
		g2D.drawString("-Properties-", (int) ((properties.x + properties.width / 2) - (getStringBounds("-Properties-").getWidth() / 2)), 622);
		g2D.drawString("Level: " + fileName, 10, 636);
		String mode = "";
		if (toolMode == WALLMODE) {
			drawBorder(wallTool.getRect());
			if (wallType == SOLID) {
				mode = "Solid";
			}
			if (wallType == BREAKABLE) {
				mode = "Breakable";
			}
			
		} else if (toolMode == POWERUPMODE) {
			drawBorder(powerupTool.getRect());
			if (powerupType == 1) {
				mode = "Ammo";
			}
			if (powerupType == 2) {
				mode = "Boost";
			}
			if (powerupType == 3) {
				mode = "Fuel";
			}
			if (powerupType == 4) {
				mode = "Health";
			}
		} else if (toolMode == FINISHMODE) {
			drawBorder(finishTool.getRect());
			mode = "";
		} else if (toolMode == ENEMYMODE) {
			drawBorder(enemyTool.getRect());
			mode = enemyHealth + " HP";
		} else if (toolMode == SPAWNMODE) {
			drawBorder(spawnTool.getRect());
			mode = spawnDirection + " Degees";
		} else if (toolMode == TEXTMODE) {
			drawBorder(textTool.getRect());
			mode = textSize + "px";
		} else if (toolMode == SELECTMODE) {
			drawBorder(selectionTool.getRect());
		}
		if(!mode.equals("")){
			g2D.setColor(new Color(0, 0, 0, 200));
			int width = g2D.getFontMetrics().stringWidth("Tool Mode: " + mode);
			Rectangle modeBack = new Rectangle((1280 / 2) - (width / 2), 575, width, 20);
			g2D.fill(modeBack);
			g2D.setColor(new Color(255, 255, 255));
			g2D.setFont(new Font("sansserif", Font.BOLD, 18));
			drawCenteredString("Tool Mode: " + mode, 590);
		}
		if (warningShown) {
			showWarning();
		}
		if (savedShown) {
			showSaved();
		}
		if (nameChanger.isShowing() || xEditor.isShowing() || wEditor.isShowing() || hEditor.isShowing() || 
				yEditor.isShowing() || textEditor.isShowing() || warningShown || savedShown) {
			dialogShowing = true;
		} else {
			dialogShowing = false;
		}
		for(Button b: toolButtons){
			b.show();
			b.drawButton(g2D);
		}
		
	}
	public void drawBorder(Rectangle rect) {
		g2D.setColor(Color.WHITE);
		g2D.fillRect(rect.x - 5, rect.y - 5, rect.width + 10, 5);
		g2D.fillRect(rect.x - 5, rect.y - 5, 5, rect.height + 10);
		g2D.fillRect(rect.x + rect.width, rect.y - 5, 5, rect.height + 10);
		g2D.fillRect(rect.x - 5, rect.y + rect.height, rect.width + 10, 5);
	}
	public void performAction(Button b) {
		if (b.equals(customLevels)){
			TankMazeRunner.showLevelSelectMenu(true);
		}else if (b.equals(changeTitle)) {
			nameChanger.show();
		} else if (b.equals(okay) && warningShown)
			warningShown = false;
		else if (b.equals(okay) && savedShown)
			savedShown = false;
		else if (b.getText().equals("Save Level") && !dialogShowing) {
			boolean saveable = false;
			for (int i = 0; i < Powerup.powerups.size(); i++) {
				if (Powerup.powerups.get(i).getType() == 5) {
					saveable = true;
					break;
				}
			}
			if (saveable)
				save();
			else
				warningShown = true;
		} else if (b.getText().equals("Draw Wall")) {
			if (toolMode == WALLMODE) {
				wallType++;
				if (wallType >= 3)
					wallType = 1;
			} else {
				toolMode = WALLMODE;
			}
			setCursor(cursor[0]);
		} else if (b.getText().equals("Add Finish")) {
			toolMode = FINISHMODE;
			setCursor(cursor[5]);
		} else if (b.getText().equals("Spawn Point")) {
			if (toolMode == SPAWNMODE) {
				spawnDirection += 10;
				if (spawnDirection >= 370)
					spawnDirection = 0;
			} else {
				toolMode = SPAWNMODE;
			}
			setCursor(cursor[0]);
		} else if (b.getText().equals("Add Enemy")) {
			if (toolMode == ENEMYMODE) {
				enemyHealth += 10;
				if (enemyHealth >= 210)
					enemyHealth = 10;
			} else {
				toolMode = ENEMYMODE;
			}
			setCursor(cursor[0]);
		} else if (b.getText().equals("Add Powerup")) {
			if (toolMode == POWERUPMODE) {
				powerupType++;
				if (powerupType >= 5)
					powerupType = 1;
				setCursor(cursor[powerupType]);
			} else {
				toolMode = POWERUPMODE;
				setCursor(cursor[powerupType]);
			}
		} else if (b.getText().equals("Write Text")) {
			if (toolMode == TEXTMODE) {
				textSize += 16;
				if (textSize > 128)
					textSize = 16;
			} else {
				toolMode = TEXTMODE;
				setCursor(cursor[0]);
			}
		} else if (b.getText().equals("Select")) {
			toolMode = SELECTMODE;
			setCursor(cursor[0]);
		} else if (!b.getText().equals("...")) {
			if (b.equals(xChanger)) {
				xEditor.show();
			}
			if (b.equals(yChanger)) {
				yEditor.show();
			}
			if (b.equals(hChanger)) {
				hEditor.show();
			}
			if (b.equals(wChanger)) {
				wEditor.show();
			}
			if(b.equals(textChanger)){
				textEditor.show();
			}
		}
	}

	private class CreateListener extends MouseAdapter implements MouseMotionListener, MouseWheelListener {
		private Point lastMousePoint = null;
		public void mouseMoved(MouseEvent e) {
			lastMousePoint = new Point(mouseX, mouseY);
			mouseY = (int) (e.getY() * invScaleY);
			mouseX = (int) (e.getX() * invScaleX);
			Point mousePoint = new Point(mouseX, mouseY);
			for(Button b: Button.buttons){
				if(b.getRect().contains(mousePoint)){
					b.hover();
					if(lastMousePoint != null && !b.getRect().contains(lastMousePoint) && b.isActive()){
						Sounds.playSound(Sounds.menuTick);
					}
				}else{
					b.idle();
				}
			}
			repaint();
		}

		public void mousePressed(MouseEvent e) {
			mouseY = (int) (e.getY() * invScaleY);
			mouseX = (int) (e.getX() * invScaleX);
			Point mousePoint = new Point(mouseX, mouseY);
			if (!e.isMetaDown() && !e.isConsumed()) {
				for(Button b: Button.buttons){
					if(b.isActive() && b.getRect().contains(mousePoint)){
						if(!dialogShowing || b.equals(okay) || b.getText().equals("Done")){
							b.click();
						}
					}
				}
				if (!dialogShowing) {
					if (toolMode == WALLMODE && mouseY < 600) {
						wallStartX = mouseX;
						wallStartY = mouseY;
						drawnWalls[counter] = new Wall(wallStartX, wallStartY,
								10, 10);
						if (wallType == BREAKABLE) {
							drawnWalls[counter].setBreakable(true);
						}
					}
					if (toolMode == POWERUPMODE) {
						if (mouseY < 600) {
							drawnPowerups[counter] = new Powerup(powerupType,
									mouseX, mouseY);
						}
					}
					if (toolMode == ENEMYMODE) {
						if (mouseY < 600) {
							drawnEnemies[counter] = new CPUTank(mouseX, mouseY);
							drawnEnemies[counter].setHealth(enemyHealth);
						}
					}
					if (toolMode == FINISHMODE) {
						if (mouseY < 600) {
							drawnPowerups[counter] = new Powerup(5, mouseX,
									mouseY);
						}
					}
					if (toolMode == SPAWNMODE) {
						if (mouseY < 600) {
							Level.spawnX = mouseX;
							Level.spawnY = mouseY;
							Level.spawnDirection = spawnDirection;
							for (Tank i : Tank.tanks) {
								if (i instanceof ControlledTank) {
									i.setX(mouseX);
									i.setY(mouseY);
									((ControlledTank) i).setDirection((spawnDirection - 180) * -1);
								}
							}
						}
					}
					if (toolMode == TEXTMODE) {
						if (mouseY < 600) {
							drawnTextFields[counter] = new TextField(text,
									mouseX, mouseY, textSize);
							drawnTextFields[counter].setBounds(g2D);
						}
					}
					if (toolMode == SELECTMODE) {
						if (mouseY < 600) {
							if (!dialogShowing) {
								checkWallClick(false);
								checkPowerupClick(false);
								checkTankClick(false);
								checkTextFieldClick(false);
								if (selectedObject != null && !dialogShowing) {
									updateButtons();
									clearTextEditors();
								}
							}
						}
					}
				}
			}
			if (!e.isConsumed() && e.isMetaDown()) {
				if (!dialogShowing) {
					checkWallClick(true);
					checkPowerupClick(true);
					checkTankClick(true);
					checkTextFieldClick(true);
				}
			}
			e.consume();
			repaint();
		}

		public void mouseDragged(MouseEvent e) {
			mouseY = (int) (e.getY() * invScaleY);
			mouseX = (int) (e.getX() * invScaleX);
			if (!e.isMetaDown() && !e.isConsumed()) {
				if (!dialogShowing) {
					if (mouseY >= 600)
						mouseY = 599;
					if (toolMode == WALLMODE) {
						int width = 10;
						if (mouseX - wallStartX > 10)
							width = mouseX - wallStartX;
						int height = 10;
						if (mouseY - wallStartY > 10)
							height = mouseY - wallStartY;
						if (drawnWalls[counter] != null)
							drawnWalls[counter].setBounds(wallStartX,
									wallStartY, width, height);
					}
				}
			}
			if (!e.isConsumed() && e.isMetaDown()) {
				if (!dialogShowing) {
					checkWallClick(true);
					checkPowerupClick(true);
					checkTankClick(true);
					checkTextFieldClick(true);
				}
			}
			e.consume();
			repaint();

		}

		public void mouseReleased(MouseEvent e) {
			if (!e.isMetaDown() && !e.isConsumed()) {
				if (!dialogShowing) {
					if (counter < 10000)
						counter++;
				}
				for(Button b: Button.buttons){
					if(b.isActive()){
						b.idle();
					}
				}
			}
			e.consume();
			repaint();
		}

		public void mouseWheelMoved(MouseWheelEvent e) {
			if (!e.isConsumed()) {
				if (e.getWheelRotation() < 0) {
					if (toolMode == POWERUPMODE) {
						powerupType++;
						if (powerupType >= 5)
							powerupType = 1;
						setCursor(cursor[powerupType]);
					}
					if (toolMode == WALLMODE) {
						wallType++;
						if (wallType >= 3)
							wallType = 1;
					}
					if (toolMode == SPAWNMODE) {
						spawnDirection += 10;
						spawnDirection %= 360;
					}
					if (toolMode == ENEMYMODE) {
						enemyHealth += 10;
						if (enemyHealth >= 210) {
							enemyHealth = 10;
						}
					}
					if (toolMode == TEXTMODE) {
						textSize += 16;
						if (textSize > 128) {
							textSize = 16;
						}
					}
				} else {
					if (toolMode == POWERUPMODE) {
						powerupType--;
						if (powerupType <= 0)
							powerupType = 4;
						setCursor(cursor[powerupType]);
					}
					if (toolMode == WALLMODE) {
						wallType--;
						if (wallType <= 0)
							wallType = 2;
					}
					if (toolMode == SPAWNMODE) {
						spawnDirection -= 10;
						spawnDirection %= 360;
					}
					if (toolMode == ENEMYMODE) {
						enemyHealth -= 10;
						if (enemyHealth <= 0) {
							enemyHealth = 200;
						}
					}
					if (toolMode == TEXTMODE) {
						textSize -= 16;
						if (textSize < 16) {
							textSize = 128;
						}
					}
				}
			}
			e.consume();
			repaint();
		}
	}

	public void showWarning() {
		g2D.setColor(new Color(255, 255, 255, 200));
		g2D.fillRect(1280 / 2 - 250, 720 / 2 - 150, 500, 200);

		g2D.setColor(new Color(0, 0, 0, 200));
		g2D.fillRect(1280 / 2 - 250 + 5, 720 / 2 - 150 + 5, 500 - 10, 200 - 10);
		g2D.setColor(new Color(0, 0, 0, 80));
		g2D.fillRect(1280 / 2 - 225, 720 / 2 - 14 - 52, 450, 20);
		g2D.setFont(new Font("sansserif", Font.BOLD, 32));
		g2D.setColor(Color.WHITE);
		drawCenteredString("Attention:", 720 / 2 - 100);
		g2D.setFont(new Font("sansserif", Font.BOLD, 16));
		drawCenteredString("You have to set at least one finish before you save!", 720 / 2 - 50);
		okay.show();
		okay.drawButton(g2D);
	}

	public void showSaved() {
		g2D.setColor(new Color(255, 255, 255, 200));
		g2D.fillRect(1280 / 2 - 250, 720 / 2 - 150, 500, 200);

		g2D.setColor(new Color(0, 0, 0, 200));
		g2D.fillRect(1280 / 2 - 250 + 5, 720 / 2 - 150 + 5, 500 - 10, 200 - 10);
		g2D.setColor(new Color(0, 0, 0, 80));
		g2D.fillRect(1280 / 2 - 225, 720 / 2 - 14 - 52, 450, 20);
		g2D.setFont(new Font("sansserif", Font.BOLD, 32));
		g2D.setColor(Color.WHITE);
		drawCenteredString("Attention:", 720 / 2 - 100);
		g2D.setFont(new Font("sansserif", Font.BOLD, 16));
		fileName = fileName.trim();
		if (fileName.equals("")) {
			fileName = "Untitled";
		}
		if (!saved) {
			drawCenteredString("SAVING...", 720 / 2 - 50);
		} else {
			drawCenteredString("Level saved as \"" + fileName + "\" in slot : "
					+ Level.levelNumber, 720 / 2 - 50);
			okay.show();
			okay.drawButton(g2D);
		}
	}

	public void save() {
		savedShown = true;
		repaint();
		File saveFile = null;
		saveFile = new File("Data/Saves/CustomLevel" + Level.levelNumber + ".txt");
		if (!saveFile.exists()) {
			try {
				saveFile.createNewFile();
			} catch (IOException e) {
			}
		}
		try {
			BufferedWriter pw = new BufferedWriter(new PrintWriter(saveFile));
			if (fileName == null) {
				fileName = "Untitled";
			}
			pw.write("NAME: " + fileName);
			pw.newLine();
			pw.write("SPAWNPOINT: x" + Level.spawnX + " y" + Level.spawnY + " d" + ((spawnDirection - 180) * -1));
			pw.newLine();
			int i;
			for (i = 0; i < Wall.walls.size(); i++) {
				Rectangle wall = Wall.walls.get(i).wall;
				if (!Wall.walls.get(i).isBreakable()) {
					String wallString = ("WALL: x" + wall.x + " y" + wall.y + " w" + wall.width + " h" + wall.height);
					if(!wallString.equals("WALL: x0 y-10 w1280 h10") && !wallString.equals("WALL: x0 y600 w1280 h10") 
							&& !wallString.equals("WALL: x1280 y0 w10 h680") && !wallString.equals("WALL: x-10 y0 w10 h680")){
						pw.write(wallString);
						pw.newLine();
					}
				} else {
					pw.write("WALL: BREAKABLE x" + wall.x + " y" + wall.y + " w" + wall.width + " h" + wall.height);
					pw.newLine();
				}
			}
			for (i = 0; i < Powerup.powerups.size(); i++) {
				Powerup p = Powerup.powerups.get(i);
				int type = p.getType();
				pw.write("POWERUP: t" + type + " x" + (p.getBounds().x + 20) + " y" + (p.getBounds().y + 20));
				pw.newLine();
			}
			for (i = 0; i < Tank.tanks.size(); i++) {
				Tank t = Tank.tanks.get(i);
				if (t instanceof CPUTank) {
					pw.write("ENEMY: h" + t.getHealth() + " x" + t.getX() + " y" + t.getY());
					pw.newLine();
				}
			}
			for(i = 0; i < TextField.textFields.size(); i++){
				TextField t = TextField.textFields.get(i);
				pw.write("TEXT: x" + t.getX() + " y" + t.getY() + " s" + t.getFontSize() + " \"" + t.getText() + "\"");
				pw.newLine();
			}
			pw.close();
		} catch (Exception e2) {
			System.out.print(e2.getLocalizedMessage());
		}
		saved = true;
	}
	public void checkWallClick(boolean remove) {
		for (int i = 0; i < Wall.walls.size(); i++) {
			if (Wall.walls.get(i).wall.contains((int) mouseX, (int) mouseY)) {
				if (remove) {
					if (selectedObject != null
							&& selectedObject.equals(Wall.walls.get(i)))
						selectedObject = null;
					Wall.walls.remove(Wall.walls.get(i));
				} else {
					if (selectedObject == null
							|| !selectedObject.equals(Wall.walls.get(i)))
						selectedObject = Wall.walls.get(i);
					else
						selectedObject = null;
				}
			}
		}
	}
	public void checkPowerupClick(boolean remove) {
		for (int i = 0; i < Powerup.powerups.size(); i++) {
			Rectangle hitbox = Powerup.powerups.get(i).getBounds();
			if (hitbox.contains((int) mouseX, (int) mouseY)) {
				if (remove) {
					if (selectedObject != null
							&& selectedObject.equals(Powerup.powerups.get(i)))
						selectedObject = null;
					Powerup.powerups.remove(Powerup.powerups.get(i));
				} else if (selectedObject == null
						|| !selectedObject.equals(Powerup.powerups.get(i)))
					selectedObject = Powerup.powerups.get(i);
				else
					selectedObject = null;
			}
		}
	}
	public void checkTankClick(boolean remove) {
		for (int i = 0; i < Tank.tanks.size(); i++) {
			if ((Tank.tanks.get(i).getTankBody().contains((int) mouseX,
					(int) mouseY))) {
				if (remove) {
					if (selectedObject != null
							&& selectedObject.equals(Tank.tanks.get(i)))
						selectedObject = null;
					if (Tank.tanks.get(i) instanceof CPUTank) {
						Tank.tanks.remove(Tank.tanks.get(i));
					} else {
						Level.spawnX = 75;
						Level.spawnY = 75;
						Level.spawnDirection = 180;
						Tank.tanks.get(i).setX(75);
						Tank.tanks.get(i).setY(75);
						((ControlledTank) Tank.tanks.get(i)).setDirection(180);
					}
				} else {
					if (selectedObject == null
							|| !selectedObject.equals(Tank.tanks.get(i)))
						selectedObject = Tank.tanks.get(i);
					else
						selectedObject = null;
				}
			}
		}
	}

	public void checkTextFieldClick(boolean remove) {
		for (int i = 0; i < TextField.textFields.size(); i++) {
			TextField t = TextField.textFields.get(i);
			t.setBounds(g2D);
			if (t.getObjectBounds().contains((int) mouseX, (int) mouseY)) {
				if (remove) {
					if (selectedObject != null && selectedObject.equals(TextField.textFields.get(i))) {
						selectedObject = null;
					}
					TextField.textFields.remove(i);
				} else {
					if (selectedObject == null || !selectedObject.equals(TextField.textFields.get(i)))
						selectedObject = TextField.textFields.get(i);
					else
						selectedObject = null;
				}
			}
		}
	}

	public void updateButtons() {
		xChanger.setText("x: " + selectedObject.getX());
		yChanger.setText("y: " + selectedObject.getY());
		try{
			wChanger.setText("w: " + ((Wall)selectedObject).getWidth());
			hChanger.setText("h: " + ((Wall)selectedObject).getHeight());
		}catch(Exception e){}
		try{
			textChanger.setText("\"" + ((TextField)selectedObject).getText() + "\"");
		}catch(Exception e){}
		for(Button b: Button.buttons){
			b.setFontSize(14);
		}
	}
	public void clearTextEditors(){
		xEditor.setText("");
		yEditor.setText("");
		wEditor.setText("");
		hEditor.setText("");
		textEditor.setText("");
	}
	public void moveObject() {
		if (selectedObject != null) {
			drawBorder(selectedObject.getObjectBounds());
			updateButtons();
			if (!xEditor.isShowing()) {
				try {
					selectedObject.setX(Integer.parseInt(xEditor.getText()));
					if(selectedObject instanceof TextField){
						((TextField) selectedObject).setBounds(g2D);
					}
				} catch (Exception e) {
					selectedObject.setX(selectedObject.getX());
				}
			}
			if (!yEditor.isShowing()) {
				try {
					selectedObject.setY(Integer.parseInt(yEditor.getText()));
					if(selectedObject instanceof TextField){
						((TextField) selectedObject).setBounds(g2D);
					}
					
				} catch (Exception e) {
					selectedObject.setY(selectedObject.getY());
				}
			}
			if (!wEditor.isShowing()) {
				try {
					int width = Integer.parseInt(wEditor.getText());
					if(width < 10)
						width = 10;
					((Wall)selectedObject).setWidth(width);
					
				} catch (Exception e) {
					try{
						((Wall)selectedObject).setWidth(((Wall)selectedObject).getWidth());
					}catch(Exception ex){
						wChanger.setText("...");
					}
				}
			}
			if (!hEditor.isShowing()) {
				try {
					int height = Integer.parseInt(hEditor.getText());
					if(height < 10)
						height = 10;
					((Wall)selectedObject).setHeight(height);
					
				} catch (Exception e) {
					try{
						((Wall)selectedObject).setHeight(((Wall)selectedObject).getHeight());
					}catch(Exception ex){
						hChanger.setText("...");
					}
				}
			}
			if (!textEditor.isShowing()) {
				try {
					if(!textEditor.getText().equals("")){
						((TextField)selectedObject).setText(textEditor.getText());
						((TextField)selectedObject).setBounds(g2D);
					}
					if(!(selectedObject instanceof TextField)){
						textChanger.setText("...");
					}
				} catch (Exception e) {
					try{
						((TextField)selectedObject).setText(((TextField)selectedObject).getText());
					}catch(Exception ex){
						textChanger.setText("...");
					}
				}
			}
		} else {
			xChanger.setText("...");
			yChanger.setText("...");
			wChanger.setText("...");
			hChanger.setText("...");
			textChanger.setText("...");
		}
	}
	private class TypeListener implements KeyListener{
		public void keyPressed(KeyEvent e) {
			for(TextEditor t: TextEditor.textEditors){
				if(t.isShowing()){
					if(e.getKeyCode() == KeyEvent.VK_BACK_SPACE && t.getText().length() > 0){
						t.setText(t.getText().substring(0, t.getText().length() - 1));
					}
					if(t.getText().length() < t.getMax() && Character.isDefined(e.getKeyChar()) && e.getKeyCode() != KeyEvent.VK_BACK_SPACE){
						t.setText(t.getText() + e.getKeyChar());
					}
				}
			}
			repaint();
		}
		public void keyReleased(KeyEvent e) {
		}
		public void keyTyped(KeyEvent e) {
		}
	}
}