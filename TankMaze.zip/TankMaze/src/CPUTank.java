import java.awt.*;

public class CPUTank extends Tank {
	private int timer = 0;
	public CPUTank(int xPosition, int yPosition){
		super(xPosition, yPosition);
		setColors(Color.RED, gunColor = Color.DARK_GRAY, lineColor = Color.WHITE);
		health = 50;
		tanks.add(this);
		bullet = new Bullet(xPosition, yPosition, Level.player.getX(), Level.player.getY());
	}
	public void fire(Graphics2D g2D){
		if(timer % 20 == 0){
			if(!bullet.isFired()){
				bullet = new Bullet(x, y, Level.player.getX(), Level.player.getY());
			}
			if(bullet.isFired()){
				bullet.drawBullet(g2D);
				bullet.move();
			}
			bullet.setFired(true);
			Sounds.playSound(Sounds.gunshot);
		}
		timer++;
	}
	public Point getTarget(Graphics2D g2D) {
		int targetX = TankMazeGame.player.getX();
		int targetY = TankMazeGame.player.getY();
		if(!TankMazeGame.paused){
			if(Math.sqrt(Math.pow(targetX - x, 2) + Math.pow(targetY - y, 2)) <= 300){
				g2D.setColor(lineColor);
				g2D.drawLine(targetX, targetY, (int)x, (int)y);
				if(!bullet.isFired()){
					bullet = new Bullet(x, y, targetX, targetY);
					fire(g2D);
				}
			}
		}
		return new Point(targetX, targetY);
	}
	
}
