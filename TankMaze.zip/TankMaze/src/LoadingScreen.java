import javax.swing.*;
import java.awt.*;
@SuppressWarnings("serial")
public class LoadingScreen extends JPanel{
	private Graphics2D g2D;
	
	public LoadingScreen(){
		int width = TankMazeRunner.WIDTH;
		int height = TankMazeRunner.HEIGHT;
		setPreferredSize(new Dimension(width, height));
	}
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g2D = (Graphics2D) g;
		setBackground(Color.BLACK);
		g2D.setColor(Color.WHITE);
		g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2D.setFont(new Font("sansserif", Font.BOLD, 48));
		drawCenteredString("Loading...", this.getHeight() / 2);
		g2D.setFont(new Font("sansserif", Font.BOLD, 18));
		int width = ImageLoader.progress * 2;
		String s = "(Please be patient. Your computer is concentrating.)";
		if(width == 180){
			s = "Don't worry, it's almost done.";
		}
		drawCenteredString(s, (this.getHeight() / 2) + 50);
		g2D.setColor(Color.RED);
		g2D.fillRect((this.getWidth() / 2) - ((90 * 2) / 2), (this.getHeight() / 2) + 15, 90 * 2, 10);
		Rectangle bar = new Rectangle((this.getWidth() / 2) - (width / 2), (this.getHeight() / 2) + 15, width, 10);
		g2D.setColor(Color.GREEN);
		g2D.fill(bar);
	}
	public void drawCenteredString(String s, int y) {
		int pos = (this.getWidth() / 2) - ((int) g2D.getFontMetrics().getStringBounds(s, g2D).getWidth() / 2);
		g2D.drawString(s, pos, y);
	}
}
