import java.net.URL;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Sounds {
	public static boolean soundOn = true;
	public static String menuTick = "Menu_Tick.wav";
	public static String menuClick = "Menu_Click.wav";
	public static String tankHit = "Car door.wav";
	public static String powerup = "Phazed bang.wav";
	public static String explosion = "Explosion_Far.wav";
	public static String gunshot = "Big drum.wav";
	public static void playSound(String name){
		if(soundOn){
			try {
		        Clip clip = AudioSystem.getClip();
		        URL url = Sounds.class.getResource(name);
		        AudioInputStream ais = AudioSystem.getAudioInputStream(url);
		        try{
		        	clip.open(ais);
			        clip.start();
		        }catch(OutOfMemoryError er){}
		    } catch (Exception e1) {}
		}
	}
}
