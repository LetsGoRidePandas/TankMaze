import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
@SuppressWarnings("serial")
public class DisplayMenu extends Panel{
	
	private Graphics2D g2D;
	private double scaleX = 1;
	private double invScaleX = 1 / scaleX;
	private double scaleY = 1;
	private double invScaleY = 1 / scaleY;
	private Button back = new Button(new Rectangle(300, 640, 1280 - 600, 60), "Back", this);
	private int mouseX;
	private int mouseY;
	
	private int sliderX = 210;
	private Rectangle slider;
	private Rectangle minus = new Rectangle(160, 285, 40, 40);
	private Rectangle plus = new Rectangle(1280 - 200, 285, 40, 40);
	private boolean sliderSelected = false;
	
	public DisplayMenu(){
		int width = TankMazeRunner.WIDTH;
		sliderX = width + 210 - 800;
		scaleX = width / 1280.0;
		scaleY = width * 9.0 / 16.0 / 720.0;
		invScaleX = 1 / scaleX;
		invScaleY = 1 / scaleY;
		Cursor menuCursor = Toolkit.getDefaultToolkit().createCustomCursor(ImageLoader.cursor, new Point(0, 0), "cursor");
		setCursor(menuCursor);
		for(Button b: Button.buttons){
			b.show();
		}
		back.setFontSize(48);
	}
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g2D = (Graphics2D)g;
		setBackground(Color.BLACK);
		g2D.scale(scaleX, scaleY);;
		g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2D.drawImage(ImageLoader.menu, 0, 0, null);
		g2D.setColor(new Color(255, 255, 255, 200));
		g2D.fillRect(200, 0, 1280 - 400, 120);
		g2D.setColor(new Color(0, 0, 0, 200));
		g2D.fillRect(210, 0, 1280 - 420, 110);
		g2D.setColor(Color.WHITE);
		g2D.setFont(new Font("sansserif", Font.BOLD, 100));
		drawCenteredString("Display", 85);
		g2D.setFont(new Font("sansserif", Font.BOLD, 48));
		//screen size
		drawCenteredString("Screen Size", 250);
		g2D.setColor(new Color(0, 0, 0, 200));
		g2D.fillRect(200, 300, 1280 - 400, 10);
		if(minus.contains(mouseX, mouseY))
			g2D.setColor(new Color(255, 255, 255, 100));
		g2D.fill(minus);
		g2D.setColor(new Color(0, 0, 0, 200));
		if(plus.contains(mouseX, mouseY))
			g2D.setColor(new Color(255, 255, 255, 100));
		g2D.fill(plus);
		g2D.setColor(Color.WHITE);
		g2D.fillRect(170, 302, 20, 5);
		g2D.fillRect(1280 - 190, 302, 20, 5);
		g2D.fillRect(1280 - 183, 295, 5, 20);
		slider = new Rectangle(sliderX - 10, 295, 20, 20);
		g2D.fill(slider);
		g2D.setFont(new Font("sansserif", Font.BOLD, 20));
		int width = (sliderX - 210 + 800);
		int height = (int) Math.round((width * 9.0 / 16.0));
		if(width > Toolkit.getDefaultToolkit().getScreenSize().width || height > Toolkit.getDefaultToolkit().getScreenSize().height){
			drawCenteredString("WARNING! These dimensions are larger than your screen! (" + Toolkit.getDefaultToolkit().getScreenSize().width + " x " + Toolkit.getDefaultToolkit().getScreenSize().height + ")", 280);
		}
		drawCenteredString("Size: " + width + " x " + height, 340);
		g2D.setColor(new Color(255, 255, 255, 50));
		g2D.setColor(Color.WHITE);
		g2D.setFont(new Font("sansserif", Font.BOLD, 48));
		for(Button b: Button.buttons){
			b.drawButton(g2D);
		}
		addMouseMotionListener(new BoxListener());
		addMouseListener(new BoxListener());
	}
	public void drawCenteredString(String s, int y){
		int pos = (1280 / 2) - ((int)g2D.getFontMetrics().getStringBounds(s, g2D).getWidth() / 2);
		g2D.drawString(s, pos, y);
	}
	private class BoxListener extends MouseAdapter implements MouseMotionListener{
		private Point mousePoint = null;
		private Point lastMousePoint = null;
		public void mouseMoved(MouseEvent e){
			if(!e.isMetaDown() && !e.isConsumed()){
				lastMousePoint = new Point(mouseX, mouseY);
				mousePoint = new Point((int)(e.getX() * invScaleX), (int)(e.getY() * invScaleY));
				mouseX = mousePoint.x;
				mouseY = mousePoint.y;
				for(Button b: Button.buttons){
					if(b.getRect().contains(mousePoint)){
						b.hover();
						if(lastMousePoint != null){
							if(!b.getRect().contains(lastMousePoint)){
								Sounds.playSound(Sounds.menuTick);
							}
						}
					}else{
						b.idle();
					}
				}
			}
			e.consume();
			repaint();
		}
		public void mousePressed(MouseEvent e){
			if(!e.isMetaDown() && !e.isConsumed()){
				lastMousePoint = new Point(mouseX, mouseY);
				mousePoint = new Point((int)(e.getX() * invScaleX), (int)(e.getY() * invScaleY));
				mouseX = mousePoint.x;
				mouseY = mousePoint.y;
				for(Button b: Button.buttons){
					if(b.getRect().contains(mousePoint)){
						b.click();
					}
				}
				if(slider.contains(mouseX, mouseY)){
					sliderSelected = true;
				}
				if(!e.isConsumed()){
					if(plus.contains(mouseX, mouseY) ){
						sliderX++;
					}
					if(minus.contains(mouseX, mouseY) ){
						sliderX--;
					}
					if(sliderX < 210)
						sliderX = 210;
					if(sliderX > 1280 - 210)
						sliderX = 1280 - 210;
					e.consume();
					repaint();
				}
			}
		}
		public void mouseReleased(MouseEvent e){
			if(!e.isMetaDown()){
				if(sliderSelected || minus.contains(mouseX, mouseY) || plus.contains(mouseX, mouseY)){
					sliderSelected = false;
					if(TankMazeRunner.WIDTH != (sliderX - 210 + 800)){
						JFrame tankMaze = TankMazeRunner.tankMaze;
						TankMazeRunner.WIDTH = (sliderX - 210 + 800);
						TankMazeRunner.HEIGHT = (int) Math.round((TankMazeRunner.WIDTH * 9.0 / 16.0));
						setPreferredSize(new Dimension(TankMazeRunner.WIDTH, TankMazeRunner.HEIGHT));
						scaleX = TankMazeRunner.WIDTH / 1280.0;
						scaleY = TankMazeRunner.WIDTH * 9.0 / 16.0 / 720.0;
						invScaleX = 1 / scaleX;
						invScaleY = 1 / scaleY;
						tankMaze.pack();
						tankMaze.setVisible(true);
						tankMaze.setLocation((Toolkit.getDefaultToolkit().getScreenSize().width / 2) - (tankMaze.getWidth() / 2), (Toolkit.getDefaultToolkit().getScreenSize().height / 2) - (tankMaze.getHeight() / 2));
					
						File settingsDirectory = new File("Data/Settings");
						if(!settingsDirectory.exists())
							settingsDirectory.mkdirs();
						try {
							BufferedWriter pw = new BufferedWriter(new FileWriter("Data/Settings/Settings.txt", true));
							pw.write("SIZE: " + TankMazeRunner.WIDTH);
							pw.newLine();
							pw.close();	
						} catch (Exception e2) {}
					}
				}
			}
		}
		public void mouseDragged(MouseEvent e){
			mouseY = (int)(e.getY() * invScaleY);
			mouseX = (int)(e.getX() * invScaleX);
			if(!e.isMetaDown()){
				if(sliderSelected){
					sliderX = mouseX;
					if(sliderX < 210)
						sliderX = 210;
					if(sliderX > 1280 - 210)
						sliderX = 1280 - 210;
					if(sliderX - 210 + 800 > Toolkit.getDefaultToolkit().getScreenSize().width){
						sliderX = Toolkit.getDefaultToolkit().getScreenSize().width - 800 + 210;
					}
				}
			}
			repaint();
		}
	}
	public void performAction(Button b) {
		if(b.equals(back)){
			TankMazeRunner.showOptions();
		}
	}
	
}
