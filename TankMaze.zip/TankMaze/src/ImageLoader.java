import java.awt.image.*;
import java.io.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;

public class ImageLoader {
	private static InputStream is;
	private static BufferedImage b;
	public static BufferedImage grass;
	public static BufferedImage ammo;
	public static BufferedImage boost;
	public static BufferedImage fuel;
	public static BufferedImage health;
	public static BufferedImage finish;
	public static BufferedImage menu;
	public static BufferedImage cursor;
	public static BufferedImage title;
	public static BufferedImage hud;
	public static BufferedImage blank;
	public static BufferedImage[] crosshairs = new BufferedImage[24];
	public static BufferedImage[] explosion = new BufferedImage[24];
	public static BufferedImage[] tank = new BufferedImage[30];
	public static BufferedImage gun;
	public static boolean isLoaded = false;
	public static int progress = 0;
	public static void loadImages(){
		try {
			grass = load("grass.png");
			ammo = load("ammo.png");
			boost = load("boost.png");
			fuel = load("fuel.png");
			health = load("health.png");
			finish = load("finish.png");
			menu = load("menu.png");
			cursor = load("menuCursor.png");
			title = load("title.png");
			hud = load("hud.png");
			blank = load("blank.png");
			for(int i = 0; i < crosshairs.length; i++){
				crosshairs[i] =  load("cursor/crosshairs" + String.format("%04d", i + 1) + ".png");
			}
			for(int i = 0; i < tank.length; i++){
				tank[i] =  load("Tank/tank" + String.format("%04d", i + 1) + ".png");
			}
			for(int i = 0; i < explosion.length; i++){
				explosion[i] =  load("Explosion/explosion" + String.format("%04d", i + 1) + ".png");
			}
			gun = load("gun.png");
			isLoaded = true;
			} catch (IOException e) {
				e.printStackTrace();
		}
	}
	private static BufferedImage load(String name) throws IOException{
		is = Level.class.getClassLoader().getResourceAsStream(name);
		b = ImageIO.read(is);
		is.close();
		progress++;
		if(TankMazeRunner.loadingScreen != null)
			TankMazeRunner.loadingScreen.repaint();
		return b;
	}
}
