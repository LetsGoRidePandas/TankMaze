//The class which contains the info for showing the main menu.
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class TankMazeOptions extends Panel{
	private static final long serialVersionUID = 1L;
	
	private Button sound = new Button(new Rectangle(300, 300, 1280 - 600, 60), "", this);
	private Button display = new Button(new Rectangle(300, 400, 1280 - 600, 60), "Display", this);
	private Button tankCustomizer = new Button(new Rectangle(300, 500, 1280 - 600, 60), "Tank Customizer", this);
	private Button back = new Button(new Rectangle(300, 600, 1280 - 600, 60), "Back", this);
	
	private int mouseY = 0;
	private int mouseX = 0;
	private double scaleX = 1;
	private double invScaleX = 1 / scaleX;
	private double scaleY = 1;
	private double invScaleY = 1 / scaleY;
	clock menuClock;
	private Graphics2D g2D;
	private static int color = 0;
	
	public TankMazeOptions(){
		int width = TankMazeRunner.WIDTH;
		int height = TankMazeRunner.HEIGHT;
		setPreferredSize(new Dimension(width, height));
		scaleX = width / 1280.0;
		scaleY = width * 9.0 / 16.0 / 720.0;
		invScaleX = 1 / scaleX;
		invScaleY = 1 / scaleY;
		menuClock = new clock();
		Cursor menuCursor = Toolkit.getDefaultToolkit().createCustomCursor(ImageLoader.cursor, new Point(0, 0), "cursor");
		setCursor(menuCursor);
		for(Button b: Button.buttons){
			b.setFontSize(48);
		}
	}
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		setBackground(Color.BLACK);
		g2D = (Graphics2D)g;
		g2D.scale(scaleX, scaleY);
		g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2D.drawImage(ImageLoader.title, 0, 0, null);
		g2D.setColor(new Color(0, 0, 0, 80));
		Rectangle menuGlass = new Rectangle(100, 215, 1080, 460);
		g2D.fill(menuGlass);
		drawSelectionBox(menuGlass);
		g2D.setColor(new Color(0, 0, 0, color));
		g2D.setFont(new Font("sansserif", Font.BOLD, 75));
		drawCenteredString("-Options-", 280);
		g2D.setColor(new Color(0, color, 0, color));
		g2D.setFont(new Font("sansserif", Font.BOLD, 72));
		drawCenteredString("-Options-", 275);
		String soundMode = "";
		if(Sounds.soundOn)
			soundMode = "On";
		else
			soundMode = "Off";
		sound.setText("Sound: " + soundMode);
		for(Button b: Button.buttons){
			b.show();
			b.drawButton(g2D);
		}
		g2D.setColor(new Color(0, 0, 0, 80));
		g2D.fillRect(200, 300, 10, 360);
		g2D.fillRect(1280 - 210, 300, 10, 360);
		
		g2D.setColor(Color.WHITE);
		int y = 300 + (600 - mouseY) + 30;
		if(y > 600)
			y = 600;
		if(y < 300)
			y = 300;
		Rectangle floatBoxL = new Rectangle(200, y, 10, 60);
		Rectangle floatBoxR = new Rectangle(1280 - 210, y, 10, 60);
		g2D.fill(floatBoxL);
		g2D.fill(floatBoxR);
		
		g2D.setColor(Color.WHITE);
		g2D.setFont(new Font("sansserif", Font.BOLD, 18));
		g2D.drawString("Created by Dylan McKinney", 1280 - (int)(g2D.getFontMetrics().getStringBounds("Created by Dylan McKinney", g2D).getWidth() + 10), 710);
		addMouseMotionListener(new BoxListener());
		addMouseListener(new BoxListener());
		try {menuClock.update();} catch (Exception e) {}
	}
	public void drawCenteredString(String s, int y){
		int pos = (1280 / 2) - ((int)g2D.getFontMetrics().getStringBounds(s, g2D).getWidth() / 2);
		g2D.drawString(s, pos, y);
	}
	public void drawSelectionBox(Rectangle rect){
		g2D.setColor(Color.WHITE);
		g2D.fillRect(rect.x - 5, rect.y - 5, rect.width + 10, 5);
		g2D.fillRect(rect.x - 5, rect.y - 5, 5, rect.height + 10);
		g2D.fillRect(rect.x + rect.width, rect.y - 5, 5, rect.height + 10);
		g2D.fillRect(rect.x - 5, rect.y + rect.height, rect.width + 10, 5);
	}
	public void drawButton(Rectangle rect, String text){
		g2D.setFont(new Font("sansserif", Font.BOLD, 48));
		if(rect.contains(mouseX, mouseY)){
			g2D.setColor(new Color(255, 255, 255, 90));
			g2D.fill(rect);
			drawSelectionBox(rect);
		}else{
			g2D.setColor(new Color(0, 0, 0, 80));
			g2D.fill(rect);
		}
		g2D.setColor(Color.WHITE);
		g2D.drawString(text, (int)((rect.x + (rect.width / 2.0)) - (getStringBounds(text).getWidth() / 2)), (int)((rect.y + (rect.height / 2.0) + getStringBounds(text).getHeight() / 4.0)));
	}
	public Rectangle2D getStringBounds(String s){
		return g2D.getFontMetrics().getStringBounds(s, g2D);
	}
	public void performAction(Button b){
		if(sound.equals(b)){
			Sounds.soundOn = !Sounds.soundOn;
			File settingsDirectory = new File("Data/Settings");
			if(!settingsDirectory.exists())
				settingsDirectory.mkdirs();
			try {
				BufferedWriter pw = new BufferedWriter(new FileWriter("Data/Settings/Settings.txt", true));
				String soundMode = "";
				if(Sounds.soundOn)
					soundMode = "On";
				else
					soundMode = "Off";
				pw.write("SOUND: " + soundMode);
				pw.newLine();
				pw.close();	
			} catch (Exception e2) {}
		}
		if(display.equals(b)){
			TankMazeRunner.showDisplayMenu();
		}
		if(tankCustomizer.equals(b)){
			TankMazeRunner.showTankCustomizer();
		}
		if(back.equals(b)){
			TankMazeRunner.showMainMenu();
		}
	}
	private class BoxListener extends MouseAdapter implements MouseMotionListener{
		private Point mousePoint = null;
		private Point lastMousePoint = null;
	public void mouseMoved(MouseEvent e){
		lastMousePoint = new Point(mouseX, mouseY);
		mousePoint = new Point((int)(e.getX() * invScaleX), (int)(e.getY() * invScaleY));
		mouseX = mousePoint.x;
		mouseY = mousePoint.y;
		for(Button b: Button.buttons){
			if(b.getRect().contains(mousePoint)){
				b.hover();
				if(lastMousePoint != null){
					if(!b.getRect().contains(lastMousePoint)){
						Sounds.playSound(Sounds.menuTick);
					}
				}
			}else{
				b.idle();
			}
		}
		e.consume();
		repaint();
	}
	public void mousePressed(MouseEvent e){
		mousePoint = new Point((int)(e.getX() * invScaleX), (int)(e.getY() * invScaleY));
		if(!e.isConsumed() && !e.isMetaDown()){
			for(Button b: Button.buttons){
				if(b.getRect().contains(mousePoint)){
					b.click();
				}
			}
		}
		e.consume();
		repaint();
	}
	public void mouseReleased(MouseEvent e){
		mousePoint = new Point((int)(e.getX() * invScaleX), (int)(e.getY() * invScaleY));
		if(!e.isConsumed() && !e.isMetaDown()){
			for(Button b: Button.buttons){
				if(b.getRect().contains(mousePoint)){
					b.hover();
				}else{
					b.idle();
				}
			}
		}
		e.consume();
		repaint();
	}
}
private class clock {
	private long delay = 10;

	boolean increasing = true;
	public synchronized void update() throws InterruptedException {
		wait(delay);
		if(color < 255 && increasing){
			color += 5;
			if(color == 255){
				increasing = false;
			}
		}else if(color > 5){
			color -= 5;
			if(color == 5){
				increasing = true;
			}
		}
		repaint();
	}
}
}
