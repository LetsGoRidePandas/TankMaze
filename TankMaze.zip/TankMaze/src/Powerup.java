import java.awt.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;

public class Powerup implements Selectable{
	public static ArrayList<Powerup> powerups;
	private int x, y;
	private static final int AMMO = 1, BOOST = 2, FUEL = 3, HEALTH = 4, FINISH = 5;
	private int type;
	private Rectangle logo;
	Graphics2D g2D;
	
	public Powerup(int t, int newX, int newY){
		type = t;
		x = newX;
		y = newY;
		powerups.add(this);
	}
	public void spawn(Graphics2D g2D){
		logo = new Rectangle(x - 20, y - 20, 40, 40);
		if(type == BOOST){
			g2D.drawImage(ImageLoader.boost, x - 20, y - 20, null);
		}else if(type == AMMO){
			g2D.drawImage(ImageLoader.ammo, x - 20, y - 20, null);
		}else if(type == FUEL){
			g2D.drawImage(ImageLoader.fuel, x - 20, y - 20, null);
		}else if(type == HEALTH){
			g2D.drawImage(ImageLoader.health, x - 20, y - 20, null);
		}else if(type == FINISH){
			g2D.drawImage(ImageLoader.finish, x - 20, y - 20, null);
		}
		
		ControlledTank player = Level.player;
		if(player != null){
			Shape tankBody = player.getTankBody();
			if(tankBody.intersects(logo) && player.isMoving() && TankMazeGame.isRunning){
				activate();
				powerups.remove(this);
			}
		}
	}
	public void activate(){
		ControlledTank player = Level.player;
		if(type == BOOST){
			player.setSpeed(5);
		}
		if(type == AMMO){
			if(player.getAmmo() + 5 <= 10)
				player.setAmmo(player.getAmmo() + 5);
			else
				player.setAmmo(10);
		}
		if(type == FUEL){
			if(player.getFuel() + 250 <= 500)
				player.setFuel(player.getFuel() + 250);
			else
				player.setFuel(500);
		}
		if(type == HEALTH){
			if(player.getHealth() + 25 <= 100)
				player.setHealth(player.getHealth() + 25);
			else
				player.setHealth(100);
		}
		if(type == FINISH){
			if(!Level.isCustom){
				try {
					BufferedWriter pw = new BufferedWriter(new FileWriter("Data/Saves/SaveData.txt", true));
					pw.write((Level.levelNumber + 1) + "");
					pw.newLine();
					pw.close();	
					TankMazeRunner.unlocked[Level.levelNumber + 1] = true;
				} catch (Exception e2) {}
			}
			TankMazeGame.isRunning = false;
			TankMazeRunner.showLevelSelectMenu(Level.isCustom);
		}
		Sounds.playSound(Sounds.powerup);
	}
	public Rectangle getBounds(){
		return logo;
	}
	public int getType(){
		return type;
	}
	public Rectangle getObjectBounds() {
		return logo;
	}
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	public void setX(int newX) {
		x = newX;	
	}
	public void setY(int newY) {
		y = newY;
	}
}
