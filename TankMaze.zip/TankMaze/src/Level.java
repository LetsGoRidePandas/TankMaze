import java.awt.*;
import java.io.*;
import java.util.*;

public class Level {
	static Graphics2D g2D;
	public static boolean isCustom = false;
	public static int levelNumber;
	public static int spawnX;
	public static int spawnY;
	public static int spawnDirection = 90;
	private static Wall[] loadedWalls = new Wall[10000];
	private static TextField[] loadedTextFields = new TextField[10000];
	private static Powerup[] loadedPowerups = new Powerup[10000];
	private static CPUTank[] loadedEnemies = new CPUTank[10000];
	public static ControlledTank player = null;
	public static String fileName = "Untitled";
	
	public static void loadLevel(){
		Wall.walls = new ArrayList<Wall>();
		spawnX = 75; spawnY = 75; spawnDirection = 180;
		TextField.textFields = new ArrayList<TextField>();
		Powerup.powerups = new ArrayList<Powerup>();
		Tank.tanks = new ArrayList<Tank>();
		player = new ControlledTank(spawnX, spawnY, spawnDirection);
		//////////////////////////////////////////////////////////////////////////////////////////////
		try{
			Scanner levelReader;
			if(!isCustom){
				InputStream is = Level.class.getClassLoader().getResourceAsStream("Level" + levelNumber + ".txt");
				levelReader = new Scanner(new InputStreamReader(is));
			}else{
				File levelFile = new File("Data/Saves/CustomLevel" + levelNumber + ".txt");
				levelReader = new Scanner(levelFile);
			}
		
		int counter = 0;
		while(levelReader.hasNextLine() && counter < 10000){
			String nextLine = levelReader.nextLine();
			if(nextLine.startsWith("SPAWNPOINT: ")){
				spawnX = Integer.parseInt(nextLine.substring(nextLine.indexOf('x') + 1, nextLine.indexOf('y') - 1));
				spawnY = Integer.parseInt(nextLine.substring(nextLine.indexOf('y') + 1, nextLine.indexOf('d') - 1));
				spawnDirection = Integer.parseInt(nextLine.substring(nextLine.indexOf('d') + 1));
				player.setX(spawnX);
				player.setY(spawnY);
				player.setDirection(spawnDirection);
			}
			if(nextLine.startsWith("WALL: ")){
				int x = Integer.parseInt(nextLine.substring(nextLine.indexOf('x') + 1, nextLine.indexOf('y') - 1));
				int y = Integer.parseInt(nextLine.substring(nextLine.indexOf('y') + 1, nextLine.indexOf('w') - 1));
				int w = Integer.parseInt(nextLine.substring(nextLine.indexOf('w') + 1, nextLine.indexOf('h') - 1));
				Color c;
				int h;
				if(nextLine.contains("r")){
					h = Integer.parseInt(nextLine.substring(nextLine.indexOf('h') + 1, nextLine.indexOf('r') - 1));
					int r = Integer.parseInt(nextLine.substring(nextLine.indexOf('r') + 1, nextLine.indexOf('g') - 1));
					int g = Integer.parseInt(nextLine.substring(nextLine.indexOf('g') + 1, nextLine.indexOf('b') - 1));
					int b = Integer.parseInt(nextLine.substring(nextLine.indexOf('b') + 1));
					c = (new Color(r, g, b));
				}else{
					h = Integer.parseInt(nextLine.substring(nextLine.indexOf('h') + 1));
					c = Color.WHITE;
				}
				loadedWalls[counter] = new Wall(x, y, w, h);
				loadedWalls[counter].setColor(c);
				if(nextLine.contains("BREAKABLE")){
					loadedWalls[counter].setBreakable(true);
				}else{
					loadedWalls[counter].setBreakable(false);
				}
			}
			if(nextLine.startsWith("POWERUP: ")){
				int t = Integer.parseInt(nextLine.substring(nextLine.indexOf('t') + 1, nextLine.indexOf('x') - 1));
				int x = Integer.parseInt(nextLine.substring(nextLine.indexOf('x') + 1, nextLine.indexOf('y') - 1));
				int y = Integer.parseInt(nextLine.substring(nextLine.indexOf('y') + 1));
				loadedPowerups[counter] = new Powerup(t, x, y);
			}
			if(nextLine.startsWith("ENEMY: ")){
				int x = Integer.parseInt(nextLine.substring(nextLine.indexOf('x') + 1, nextLine.indexOf('y') - 1));
				int y = Integer.parseInt(nextLine.substring(nextLine.indexOf('y') + 1));
				loadedEnemies[counter] = new CPUTank(x, y);
				if(nextLine.contains("h")){
					int h = Integer.parseInt(nextLine.substring(nextLine.indexOf('h') + 1, nextLine.indexOf('x') - 1));
					loadedEnemies[counter].setHealth(h);
				}
			}
			if(nextLine.startsWith("TEXT: ")){
				int x = Integer.parseInt(nextLine.substring(nextLine.indexOf('x') + 1, nextLine.indexOf('y') - 1));
				int y = Integer.parseInt(nextLine.substring(nextLine.indexOf('y') + 1, nextLine.indexOf('s') - 1));
				int s = Integer.parseInt(nextLine.substring(nextLine.indexOf('s') + 1, nextLine.indexOf('\"') - 1));
				String str = nextLine.substring(nextLine.indexOf('\"') + 1, nextLine.indexOf('\"', nextLine.indexOf('\"') + 1));
				loadedTextFields[counter] = new TextField(str, x, y, s);
			}
			if(nextLine.startsWith("NAME: ")){
				if(nextLine.length() > 15)
					fileName = nextLine.substring(6, 15);
				else
					fileName = nextLine.substring(6);
				fileName = fileName.trim();
				if(fileName.equals("")){
					fileName = "Untitled";
				}
			}
			counter++;
		}
		}catch(Exception e){
			fileName = "Untitled";
		}
		Wall wall1 = new Wall(0, -10, 1280, 10);
		Wall wall2 = new Wall(0, 600, 1280, 10);
		Wall wall3 = new Wall(-10, 0, 10, 680);
		Wall wall4 = new Wall(1280, 0, 10, 680);
	}
	public static void showLevel(Graphics2D g2D){
		for(int i = 0; i < Wall.walls.size(); i++){
			Wall.walls.get(i).spawn(g2D);
		}
		for(int i = 0; i < Powerup.powerups.size(); i++){
			Powerup.powerups.get(i).spawn(g2D);
		}
		for(int i = 0; i < Tank.tanks.size(); i++){
			if(!TankMazeGame.paused && Tank.tanks.get(i) instanceof ControlledTank){
				((ControlledTank) Tank.tanks.get(i)).move();
				((ControlledTank) Tank.tanks.get(i)).turn();
			}
			Tank.tanks.get(i).spawn(g2D);
		}
		for(int i = 0; i < TextField.textFields.size(); i++){
			TextField.textFields.get(i).spawn(g2D);
		}
	}
}
