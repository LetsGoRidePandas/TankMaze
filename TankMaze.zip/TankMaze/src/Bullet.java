import java.awt.Color;
import java.awt.Graphics2D;

public class Bullet{
	private double x, y, startingX, startingY, targetX, targetY;
	private boolean fired = false;
	public double distance = 0;
	double direction = Math.toRadians(90);
	
	public Bullet(double sX, double sY, double tX, double tY){
		x = sX;
		y = sY;
		startingX = sX;
		startingY = sY;
		targetX = tX;
		targetY = tY;
		if(targetY - y != 0){
			direction = Math.atan((targetX - x) / (targetY - y));
		}else{
			if(targetX > x){
				direction = Math.toRadians(90);
			}else{
				direction = Math.toRadians(-90);
			}
		}
	}
	public void drawBullet(Graphics2D g2D){
		g2D.setColor(Color.WHITE);
		g2D.fillOval((int)(x - 4), (int)(y - 4), 8, 8);
		
	}
	public void move(){
		if(targetY < startingY){
			y -= Math.sin(direction + Math.toRadians(90)) * 10;
			x += Math.cos(direction + Math.toRadians(90)) * 10;
		}else{
			y -= Math.sin(direction - Math.toRadians(90)) * 10;
			x += Math.cos(direction - Math.toRadians(90)) * 10;
		}
		distance = Math.sqrt(Math.pow((x - startingX), 2) + Math.pow((y - startingY), 2));
		if(distance > 300){
			fired = false;
			x = startingX;
			y = startingY;
		}
	}
	public double getX(){
		return x;
	}
	public double getY(){
		return y;
	}
	public void setFired(boolean newFired){
		fired = newFired;
	}
	public boolean isFired(){
		return fired;
	}
}