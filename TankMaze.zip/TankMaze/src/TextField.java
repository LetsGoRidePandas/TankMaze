import java.awt.*;
import java.util.ArrayList;
public class TextField implements Selectable{

	public static ArrayList<TextField> textFields;
	private int fontSize;
	private String text;
	private int x;
	private int y;
	private Color textColor = Color.WHITE;
	private Rectangle bounds = new Rectangle();
	
	public TextField(String str, int xPosition, int yPosition, int size){
		textFields.add(this);
		text = str; x = xPosition; y = yPosition; fontSize = size;
	}
	public void setColor(Color newColor){
		textColor = newColor;
	}
	public void spawn(Graphics2D g2D){
		g2D.setFont(new Font("sansserif", Font.BOLD, fontSize));
		g2D.setColor(textColor);
		g2D.drawString(text, x, y);
	}
	public void setBounds(Graphics2D g2D){
		g2D.setFont(new Font("sansserif", Font.BOLD, fontSize));
		int height = g2D.getFontMetrics().getAscent() - g2D.getFontMetrics().getMaxDescent();
		bounds.setBounds(x, y - height, g2D.getFontMetrics().stringWidth(text), height);
	}
	public int getX(){
		return x;
	}
	public int getY(){
		return y;
	}
	public Rectangle getObjectBounds() {
		return bounds;
	}
	public void setX(int newX) {
		x = newX;	
	}
	public void setY(int newY) {
		y = newY;
	}
	public void setText(String text2) {
		text = text2;
	}
	public String getText(){
		return text;
	}
	public int getFontSize(){
		return fontSize;
	}
}
