//Runs the game and displays the different types of windows.
import java.awt.*;
import java.io.*;
import javax.swing.*;
import java.util.*;

public class TankMazeRunner{
	static Container pane;
	static JFrame tankMaze;
	static TankMazeMenu mainMenu;
	public static TankMazeGame game;
	public static TankCustomizer customizer;
	public static int WIDTH = 800;
	public static int HEIGHT = (int)(WIDTH * (9.0 / 16.0));
	public static boolean[] unlocked;
	public static boolean loaded = false;
	public static LoadingScreen loadingScreen = null;
	public static void main(String args[]){
		//Makes the window
		try{
			PrintStream out = new PrintStream(new FileOutputStream("Data/error_log.txt"));
			//System.setErr(out);
		}catch(Exception e){
			e.printStackTrace();
		}
		tankMaze = new JFrame();
		tankMaze.setTitle("TankMaze");
		tankMaze.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		tankMaze.setResizable(false);
		pane = tankMaze.getContentPane();
		try{
			Scanner settingsReader = new Scanner(new File("Data/Settings/Settings.txt"));
			while(settingsReader.hasNextLine()){
				String str = settingsReader.nextLine();
				if(str.startsWith("SIZE: ")){
					WIDTH = Integer.parseInt(str.substring(6));
					HEIGHT = (int)(WIDTH * (9.0 / 16.0));
				}
				if(str.startsWith("SOUND: ")){
					String soundMode = str.substring(6).trim();
					if(soundMode.equals("On")){
						Sounds.soundOn = true;
					}else if(soundMode.equals("Off")){
						Sounds.soundOn = false;
					}
				}
			}
			settingsReader.close();
		}catch (FileNotFoundException e) {}
		//loads information
		unlocked = new boolean[51];
		if(! new File("Data/Saves").exists())
			new File("Data/Saves").mkdirs();
		for(int i = 1; i <= 50; i++){
			if(i == 1){
				unlocked[i] = true;
			}
			try{
				Scanner dataReader = new Scanner(new File("Data/Saves/SaveData.txt"));
				while(dataReader.hasNextLine()){
					String nextLine = dataReader.nextLine();
					if(nextLine.startsWith("" + i)){
						unlocked[i] = true;
						break;
					}
				}
			}catch(FileNotFoundException e){}
		}
		
		Thread t1 = new Thread(new Runnable(){
			public void run() {
				ImageLoader.loadImages();
				showMainMenu();
			}	
		});
		Thread t2 = new Thread(new Runnable(){
			public void run(){
				showLoadingScreen();
				tankMaze.setLocation((Toolkit.getDefaultToolkit().getScreenSize().width / 2) - (tankMaze.getWidth() / 2), (Toolkit.getDefaultToolkit().getScreenSize().height / 2) - (tankMaze.getHeight() / 2));
			}	
		});
		t1.start();
		t2.start();
		///////////////////////////////////////////////////////////////////////////////////
	}
	public static void showLoadingScreen(){
		loadingScreen = new LoadingScreen();
		pane.add(loadingScreen);
		tankMaze.pack();
		tankMaze.setVisible(true);
	}
	public static void showMainMenu(){
		//Displays the main menu
		Button.clear();
		loadingScreen = null;	
		mainMenu = new TankMazeMenu();
		pane.removeAll();
		pane.add(mainMenu);
		tankMaze.pack();
		tankMaze.setVisible(true);
	}
	//Replaces the main menu with the options menu
	public static void showLevelCustomizer(){
		Button.clear();
		LevelCustomizer levelMaker = new LevelCustomizer();
		pane.removeAll();
		pane.add(levelMaker);
		tankMaze.setVisible(true);

	}
	public static void showOptions(){	
		Button.clear();
		TankMazeOptions options = new TankMazeOptions();
		pane.removeAll();
		pane.add(options);
		tankMaze.setVisible(true);
	}
	public static void showDisplayMenu(){
		Button.clear();
		DisplayMenu displayMenu = new DisplayMenu();
		pane.removeAll();
		pane.add(displayMenu);
		tankMaze.setVisible(true);
	}
	public static void startGame(){
		Button.clear();
		game = new TankMazeGame();
		pane.removeAll();
		pane.add(game);
		tankMaze.setVisible(true);
	}
	public static void showTankCustomizer(){
		Button.clear();
		pane.removeAll();
		customizer = new TankCustomizer();
		pane.add(customizer);
		tankMaze.setVisible(true);
	}
	public static void showLevelSelectMenu(boolean custom){
		Button.clear();
		LevelSelectMenu levelSelect = new LevelSelectMenu(custom);
		pane.removeAll();
		pane.add(levelSelect);
		tankMaze.setVisible(true);
	}
}	