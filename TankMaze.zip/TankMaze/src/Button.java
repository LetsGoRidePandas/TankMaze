import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

public class Button {
	private String text;
	private Rectangle rect;
	public static ArrayList<Button> buttons = new ArrayList<Button>();
	public static int mouseX, mouseY;
	public static boolean mouseDown = false;
	private boolean hovering = false;
	private boolean isActive = false;
	private Panel panel;
	private Color color = new Color(0, 0, 0, 200);
	private int drawnFontSize = 14;
	private int actualFontSize = 14;
	private Font font = new Font("sansserif", Font.BOLD, actualFontSize);
	public Button(Rectangle r, String t, Panel p){
		panel = p;
		rect = r;
		text = t;
		buttons.add(this);
	}
	public static void clear(){
		buttons = new ArrayList<Button>();
	}
	public void drawButton(Graphics2D g2D){
		if(isActive){
			g2D.setFont(font);
			g2D.setColor(color);
			g2D.fill(rect);
			g2D.setColor(Color.WHITE);
			drawnFontSize = actualFontSize;
			while(g2D.getFontMetrics().stringWidth(text) > rect.width){
				drawnFontSize--;
				font = new Font("sansserif", Font.BOLD, drawnFontSize);
				g2D.setFont(font);
			}
			g2D.drawString(text, (int)((rect.x + (rect.width / 2.0)) - (getStringBounds(g2D).getWidth() / 2)), (int)((rect.y + (rect.height / 2.0) + getStringBounds(g2D).getHeight() / 4.0)));
			if(hovering){
				g2D.setColor(Color.WHITE);
				g2D.fillRect(rect.x - 5, rect.y - 5, rect.width + 10, 5);
				g2D.fillRect(rect.x - 5, rect.y - 5, 5, rect.height + 10);
				g2D.fillRect(rect.x + rect.width, rect.y - 5, 5, rect.height + 10);
				g2D.fillRect(rect.x - 5, rect.y + rect.height, rect.width + 10, 5);
			}
		}
	}
	public void click(){
		Sounds.playSound(Sounds.menuClick);
		panel.performAction(this);
		setColor(new Color(255, 255, 255, 100));
		panel.repaint();
	}
	public void hover(){
		hovering = true;
		setColor(new Color(0, 0, 0, 255));
	}
	public void idle(){
		hovering = false;
		setColor(new Color(0, 0, 0, 200));
	}
	public Rectangle2D getStringBounds(Graphics2D g2D){
		return g2D.getFontMetrics().getStringBounds(text, g2D);
	}
	public String getText(){
		return text;
	}
	public Rectangle getRect(){
		return rect;
	}
	public void setText(String s){
		if(!s.equals(""))
			text = s;
	}
	public void setColor(Color c){
		color = c;
	}
	public boolean isActive(){
		return isActive;
	}
	public void show(){
		isActive = true;
	}
	public void hide(){
		isActive = false;
	}
	public void setFontSize(int i){
		actualFontSize = i;
		font = new Font("sansserif", Font.BOLD, actualFontSize);
	}
	public boolean isHovering(){
		return hovering;
	}
}
