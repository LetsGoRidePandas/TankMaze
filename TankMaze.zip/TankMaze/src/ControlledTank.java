import java.awt.*;
public class ControlledTank extends Tank{
	private double fuel = 500;
	private int ammo = 10;
	private double deltaX, deltaY;
	private int frameCounter = 0;
	
	public ControlledTank(int xPosition, int yPosition, double d){
		super(xPosition, yPosition, d);
		tanks.add(this);
		health = 100;
		bullet = new Bullet(xPosition, yPosition, TankMazeGame.mouseX, TankMazeGame.mouseY);
	}
	public Image getOverlay(){
		if(frameCounter < 0)
			frameCounter = 29;
		if(frameCounter > 29)
			frameCounter = 0;
		return ImageLoader.tank[frameCounter];
	}
	public void fire(Graphics2D g2D){
		bullet.setFired(true);
		ammo--;
		Sounds.playSound(Sounds.gunshot);
	}
	public void move(){
		if(movement == 'w' && fuel > 0 || movement == 'W' && fuel > 0){
			x -= deltaX;
			y -= deltaY;
			if(speed < 3)
				speed += .25;
			fuel -= 1;
			frameCounter++;
		}
		if(movement == 's' && fuel > 0 || movement == 'S' && fuel > 0){
			x += deltaX;
			y += deltaY;
			if(speed < 2)
				speed += .25;
			fuel -= .5;
			frameCounter--;
		}
		transformer.rotate(Math.toRadians(direction + 90), x, y);
		tankBody = new Rectangle((int)x - 25, (int)(y - 37.5), 50, 75);
		tankBody = transformer.createTransformedShape(tankBody);
		transformer.rotate(Math.toRadians(-direction - 90), x, y);
		for(int i = 0; i < Wall.walls.size(); i++){
			if(tankBody.intersects(Wall.walls.get(i).wall) && !Wall.walls.get(i).isBroken()){
				moveNegative();
			}
		}
		for(int i = 0; i < tanks.size(); i++){
			if(tanks.get(i) != this){
				if(tankBody.intersects(tanks.get(i).getTankBody().getBounds2D()))
				moveNegative();
			}
		}
	}
	public void moveNegative(){
		if(movement == 'w' || movement == 'W'){
			x += deltaX;
			y += deltaY;
			if(speed < 3)
				speed += .25;
			fuel += 1;
			frameCounter--;
		}
		if(movement == 's' || movement == 'S'){
			x -= deltaX;
			y -= deltaY;
			if(speed < 2)
				speed += .25;
			fuel += .5;
			frameCounter++;
		}	
	}
	public void turn(){
		if(turning == 'a' && fuel > 0 || turning == 'A' && fuel > 0){
			direction -= 2;
			fuel -= .25;
		}
		if(turning == 'd' && fuel > 0 || turning == 'D' && fuel > 0){
			direction += 2;
			fuel -= .25;
		}
		transformer.rotate(Math.toRadians(direction + 90), x, y);
		tankBody = new Rectangle((int)x - 25, (int)(y - 37.5), 50, 75);
		tankBody = transformer.createTransformedShape(tankBody);
		transformer.rotate(Math.toRadians(-direction - 90), x, y);
		for(int i = 0; i < Wall.walls.size(); i++){
			if(tankBody.intersects(Wall.walls.get(i).wall) && !Wall.walls.get(i).isBroken()){
				turnNegative();
			}
		}
		for(int i = 0; i < tanks.size(); i++){
			if(tanks.get(i) != this){
				if(tankBody.intersects(tanks.get(i).getTankBody().getBounds2D()))
				turnNegative();
			}
		}
	}	
	public void turnNegative(){
		if(turning == 'a' || turning == 'A'){
			direction += 2;
			fuel += .25;
		}
		if(turning == 'd' || turning == 'D'){
			direction -= 2;
			fuel += .25;
		}
	}
	public void setAmmo(int newAmmo){
		ammo = newAmmo;
	}
	public int getAmmo(){
		return ammo;
	}
	public void setFuel(double d){
		fuel = d;
	}
	public double getFuel(){
		return fuel;
	}
	public Point getTarget(Graphics2D g2D) {
		int targetX = (int)TankMazeGame.mouseX;
		int targetY = (int)TankMazeGame.mouseY;
		if(!TankMazeGame.paused){
			g2D.setColor(lineColor);
			g2D.drawLine((int)x, (int)y, targetX, targetY);	
		}
		return new Point(targetX, targetY);
	}
	public void setSpeed(double newSpeed){
		speed = newSpeed;
	}
	public void setDirection(double d){
		direction = d;
	}
	public void setMovement(char m){
		movement = m;
		deltaY = (Math.sin(Math.toRadians(direction))) * speed;
		deltaX = (Math.cos(Math.toRadians(direction))) * speed;
	}
	public void setTurning(char c){
		turning = c;
	}
	public char getMovement(){
		return movement;
	}
}
