import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
@SuppressWarnings("serial")
public class TankCustomizer extends Panel{
	private Point mousePoint = null;
	double scaleX, scaleY, invScaleX, invScaleY;
	private Color tankColor, gunColor, lineColor;
	ControlledTank displayTank;
	private Graphics2D g2D;
	public TankCustomizer(){
		scaleX = TankMazeRunner.WIDTH / 1280.0;
		scaleY = TankMazeRunner.WIDTH * 9.0 / 16.0 / 720.0;
		invScaleX = 1 / scaleX;
		invScaleY = 1 / scaleY;
		Tank.tanks = new ArrayList<Tank>();
		displayTank = new ControlledTank(640, 300, 90);
		tankColor = displayTank.getColors()[0];
		gunColor = displayTank.getColors()[1];
		lineColor = displayTank.getColors()[2];
		addMouseListener(new CustomListener());
		addMouseMotionListener(new CustomListener());
	}
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g2D = (Graphics2D)g;
		g2D.scale(scaleX, scaleY);
		g2D.drawImage(ImageLoader.grass, 0, 0, null);
		displayTank.spawn(g2D);
	}
	private class CustomListener extends MouseAdapter implements MouseMotionListener{
		public void mouseMoved(MouseEvent e){
			if(!e.isConsumed()){
				mousePoint = new Point((int)(e.getY() * invScaleY), (int)(e.getX() * invScaleX));
			}
			e.consume();
		}
	}
	public void performAction(Button b) {
		
	}
}
