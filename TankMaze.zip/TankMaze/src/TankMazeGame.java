import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

@SuppressWarnings("serial")
public class TankMazeGame extends JPanel {
	public static boolean isRunning = false;
	Graphics2D g2D;
	private clock gameClock;
	public static ControlledTank player;
	public char playerMovement = ' ', playerTurning = ' ';
	public static double mouseX, mouseY;
	int[] boxPositions = {215, 265, 315, 365, getHeight() - 100 };
	int location = 4;
	Rectangle pauseButton = new Rectangle(1280 - 110, 628, 100, 32);
	Rectangle retryButton = new Rectangle(1280 - 110, 676, 100, 32);
	Rectangle mainMenu = new Rectangle((1280 / 2) - 50, 628, 100, 32);
	public static boolean paused = false;
	public static String pauseMessage = "PAUSED";
	double scaleX, scaleY, invScaleX, invScaleY;
	public static ArrayList<Explosion> explosions = new ArrayList<Explosion>();

	private int frameCounter = 1;

	public TankMazeGame() {
		isRunning = true;
		setBackground(Color.BLACK);
		scaleX = TankMazeRunner.WIDTH / 1280.0;
		scaleY = TankMazeRunner.WIDTH * 9.0 / 16.0 / 720.0;
		invScaleX = 1 / scaleX;
		invScaleY = 1 / scaleY;
		gameClock = new clock();
		Level.loadLevel();
		player = Level.player;
		pauseMessage = "PAUSED";
		paused = false;

		Cursor menuCursor = Toolkit.getDefaultToolkit().createCustomCursor(ImageLoader.blank, new Point(0, 0), "cursor");
		setCursor(menuCursor);
	}
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g2D = (Graphics2D)g;
		g2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
		g2D.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
		g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2D.scale(scaleX, scaleY);
		g2D.drawImage(ImageLoader.grass, 0, 0, null);
		//Updates the game in regular intervals
		try {gameClock.update();} catch (Exception e) {}
		//Add control functionality
		grabFocus();
		addKeyListener(new Controller());
		addMouseMotionListener(new AimListener());
		addMouseListener(new AimListener());
		//keeps pause screen ready if the game is paused
		Level.showLevel(g2D);
		for(int i = 0; i < Tank.tanks.size(); i++){
			if(Tank.tanks.get(i).getHealth() <= 0){
				explosions.add(new Explosion((int)Tank.tanks.get(i).getX(), (int)Tank.tanks.get(i).getY()));
				if(Tank.tanks.get(i) instanceof ControlledTank){
					pauseMessage = "Game Over";
					paused = true;
				}
				Tank.tanks.remove(i);
			}else if(Tank.tanks.get(i) instanceof ControlledTank){
				if(((ControlledTank)Tank.tanks.get(i)).getFuel() <= 0){
					pauseMessage = "Game Over";
					paused = true;
				}else if(((ControlledTank)Tank.tanks.get(i)).getFuel() < 100){
					g2D.setColor(Color.WHITE);
					g2D.setFont(new Font("sansserif", Font.BOLD, 18));
					g2D.drawString("WARNING: Low Fuel!", (1280 / 2) - (g2D.getFontMetrics().stringWidth("WARNING: Low Fuel!") / 2), 600);
				}
				
			}
		}
		for(int i = 0; i < explosions.size(); i++){
			explosions.get(i).spawn(g2D);
		}
		drawHUD(g2D);
		if (paused == true) {
			drawPauseScreen(g2D);
		}

		frameCounter++;
		if(frameCounter > 23)
			frameCounter = 0;
		g2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2D.drawImage(ImageLoader.crosshairs[frameCounter], (int)mouseX - 16, (int)mouseY - 16, null);
	}
	public void drawBorder(Rectangle rect) {
		g2D.setColor(Color.WHITE);
		g2D.fillRect(rect.x - 5, rect.y - 5, rect.width + 10, 5);
		g2D.fillRect(rect.x - 5, rect.y - 5, 5, rect.height + 10);
		g2D.fillRect(rect.x + rect.width, rect.y - 5, 5, rect.height + 10);
		g2D.fillRect(rect.x - 5, rect.y + rect.height, rect.width + 10, 5);
	}
	public void drawHUD(Graphics2D g2D){
		g2D.drawImage(ImageLoader.hud, 0, 600, null);
		Rectangle hudBar = new Rectangle(5, 605, 1280 - 10, 110);
		drawBorder(hudBar);
		g2D.setColor(Color.WHITE);
		g2D.setFont(new Font("sansserif", Font.BOLD, 18));
		if(Level.isCustom){
			g2D.drawString("Level: " + Level.fileName, 10, 636);
		}else{
			g2D.drawString("Level: " + Level.levelNumber, 10, 636);
		}
		g2D.setFont(new Font("sansserif", Font.BOLD, 16));
		g2D.drawString("Health: ", 10, 668);
		g2D.drawString("Fuel: ", 10, 684);
		g2D.drawString("Ammo: ", 10, 700);
		g2D.setColor(Color.BLACK);
		g2D.fillRect(70, 658, 100, 10);
		g2D.fillRect(70, 674, 100, 10);
		g2D.setColor(Color.RED);
		g2D.fillRect(70, 658, player.getHealth(), 10);
		g2D.setColor(Color.GREEN);
		g2D.fillRect(70, 674, (int)(player.getFuel() / 5), 10);
		g2D.setColor(Color.WHITE);
		for(int i = 0; i < player.getAmmo(); i++){
			g2D.fillRect((int)(70 + (10.5 * i)), 690, 5, 10);
		}
		if(!pauseMessage.equals("Game Over")){
			if(pauseButton.contains(mouseX, mouseY)){
				g2D.setColor(new Color(255, 255, 255, 90));
			}else{
				g2D.setColor(new Color(0, 0, 0, 80));
			}
			g2D.fill(pauseButton);
			g2D.setColor(Color.WHITE);
			if(!paused){
				g2D.drawString("Pause", (1280 - 110 + 50) - (int)(g2D.getFontMetrics().getStringBounds("Pause", g2D).getWidth() / 2), 652);
			}else{
				g2D.drawString("Resume", (1280 - 110 + 50) - (int)(g2D.getFontMetrics().getStringBounds("Resume", g2D).getWidth() / 2), 652);
			}
		}
		if(paused){
			if(retryButton.contains(mouseX, mouseY)){
				g2D.setColor(new Color(255, 255, 255, 90));
			}else{
				g2D.setColor(new Color(0, 0, 0, 80));
			}
			g2D.fill(retryButton);
			g2D.setColor(Color.WHITE);
			g2D.drawString("Retry", (1280 - 110 + 50) - (int)(g2D.getFontMetrics().getStringBounds("Retry", g2D).getWidth() / 2), 700);
		}
	}
	public void drawPauseScreen(Graphics g) {
		g2D.setColor(new Color(255, 255, 255, 100));
		g2D.fillRect(0, 0, 1280, 600);
		g2D.setFont(new Font("sansserif", Font.BOLD, 128));
		g2D.setColor(new Color(0, 0, 0, 80));
		g2D.drawString(pauseMessage, 1280 / 2 - (int)(g2D.getFontMetrics().getStringBounds(pauseMessage, g2D).getWidth() / 2), 350);
		
		if(mainMenu.contains(mouseX, mouseY)){
			g2D.setColor(new Color(255, 255, 255, 90));
		}else{
			g2D.setColor(new Color(0, 0, 0, 80));
		}
		g2D.fill(mainMenu);
		g2D.setFont(new Font("sansserif", Font.BOLD, 16));
		g2D.setColor(Color.WHITE);
		g2D.drawString("Main Menu", (1280 / 2) - (int)(g2D.getFontMetrics().getStringBounds("Main Menu", g2D).getWidth() / 2), 652);
	}
	public void drawCenteredString(String s, int y) {
		int pos = (this.getWidth() / 2)	- ((int) g2D.getFontMetrics().getStringBounds(s, g2D).getWidth() / 2);
		g2D.drawString(s, pos, y);
	}
	private class Controller implements KeyListener {
		public void keyPressed(KeyEvent e) {
			e.consume();
		}
		public void keyReleased(KeyEvent e) {
			if (e.getKeyChar() == 'w' || e.getKeyChar() == 'W') {
				playerMovement = ' ';
				player.setSpeed(0);
			}
			if (e.getKeyChar() == 's' || e.getKeyChar() == 'S') {
				playerMovement = ' ';
				player.setSpeed(0);
			}
			if (e.getKeyChar() == 'a' || e.getKeyChar() == 'A')
				playerTurning = ' ';
			if (e.getKeyChar() == 'd' || e.getKeyChar() == 'D')
				playerTurning = ' ';
			e.consume();
		}
		public void keyTyped(KeyEvent e) {
			if ((e.getKeyChar() == 'w' || e.getKeyChar() == 's') && !paused) {
				playerMovement = e.getKeyChar();
			}
			if ((e.getKeyChar() == 'W' || e.getKeyChar() == 'S') && !paused) {
				playerMovement = e.getKeyChar();
			}
			if ((e.getKeyChar() == 'a' || e.getKeyChar() == 'd') && !paused) {
				playerTurning = e.getKeyChar();
			}
			if ((e.getKeyChar() == 'A' || e.getKeyChar() == 'D') && !paused) {
				playerTurning = e.getKeyChar();
			}
			e.consume();
		}
	}
	private class AimListener extends MouseAdapter implements MouseMotionListener{
		public void mouseDragged(MouseEvent e) {
			mouseY = (int)(e.getY() * invScaleY);
			mouseX = (int)(e.getX() * invScaleX);
		}
		public void mouseMoved(MouseEvent e) {
			mouseY = (int)(e.getY() * invScaleY);
			mouseX = (int)(e.getX() * invScaleX);
		}
		public void mousePressed(MouseEvent e) {
			Point mousePoint = new Point((int)(e.getX() * invScaleX), (int)(e.getY() * invScaleY));
			if(!e.isConsumed()){
				if(!paused && !e.isMetaDown() && e.getY() * invScaleY < 600){
					if(player.getAmmo() > 0 && !player.getBullet().isFired()){
						player.fire(g2D);
					}
				}else if(!paused && !e.isMetaDown() && pauseButton.contains(mousePoint)){
					paused = true;
				}else if(paused && !e.isMetaDown() && pauseButton.contains(mousePoint) && !pauseMessage.equals("Game Over")){
					paused = false;
				}else if(paused && !e.isMetaDown() && mainMenu.contains(mousePoint)){
					isRunning = false;
					TankMazeRunner.showMainMenu();
					setVisible(true);
				}else if(!e.isMetaDown() && retryButton.contains(mousePoint) && paused){
					Level.loadLevel();
					player = Level.player;
					pauseMessage = "PAUSED";
					paused = false;
				}
			}
			e.consume();
		}
	}
	private class clock {
		private long delay = 10;
		public synchronized void update() throws InterruptedException {
			wait(delay);
			player.setMovement(playerMovement);
			player.setTurning(playerTurning);
			repaint();
		}
	}
}
