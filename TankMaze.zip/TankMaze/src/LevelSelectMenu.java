import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class LevelSelectMenu extends Panel{
	
	private static final long serialVersionUID = 1L;
	private Graphics2D g2D;
	private double scaleX = 1;
	private double invScaleX = 1 / scaleX;
	private double scaleY = 1;
	private double invScaleY = 1 / scaleY;
	private Button[] levelButtons = new Button[50];
	private int mouseX;
	private int mouseY;
	private Button mainMenu = new Button(new Rectangle(300, 640, 1280 - 600, 60), "Main Menu", this);
	private boolean custom;
	Rectangle edit = new Rectangle(1280 / 2 - 230, 400 - 32, 100, 32);
	Rectangle play = new Rectangle(1280 / 2 - 110, 400 - 32, 100, 32);
	Rectangle delete = new Rectangle(1280 / 2 + 10, 400 - 32, 100, 32);
	Rectangle cancel = new Rectangle(1280 / 2 + 130, 400 - 32, 100, 32);
	private int slot;
	private boolean optionsShown = false;
	public LevelSelectMenu(boolean c){
		custom = c;
		int width = TankMazeRunner.WIDTH;
		scaleX = width / 1280.0;
		scaleY = width * 9.0 / 16.0 / 720.0;
		invScaleX = 1 / scaleX;
		invScaleY = 1 / scaleY;
		Cursor menuCursor = Toolkit.getDefaultToolkit().createCustomCursor(ImageLoader.cursor, new Point(0, 0), "cursor");
		setCursor(menuCursor);
		mainMenu.show();
		mainMenu.setFontSize(48);
		int counter = 0;
		for(int y = 0; y < 5; y++){
			for(int x = 0; x < 10; x++){
				Rectangle rect = new Rectangle((x * 100) + (x * 10) + 95, (y * 90) + (y * 10) + 130, 100, 90);
				levelButtons[counter] = new Button(rect, (counter + 1) + "", this);
				counter++;
			}
		}
	}
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g2D = (Graphics2D) g;
		setBackground(Color.BLACK);
		g2D.scale(scaleX, scaleY);
		g2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2D.drawImage(ImageLoader.menu, 0, 0, null);
		g2D.setColor(new Color(255, 255, 255, 200));
		g2D.fillRect(200, 0, 1280 - 400, 120);
		g2D.setColor(new Color(0, 0, 0, 200));
		g2D.fillRect(210, 0, 1280 - 420, 110);
		g2D.setColor(Color.WHITE);
		g2D.setFont(new Font("sansserif", Font.BOLD, 120));
		if(!custom)
			drawCenteredString("Level Select", 100);
		else
			drawCenteredString("Custom Levels", 100);
		
		//draw the boxes
		
		for(Button b :Button.buttons){
			b.show();
			if(!b.equals(mainMenu))
				b.setFontSize(72);
			if(b.isHovering() && !b.equals(mainMenu)){
				b.setFontSize(76);
			}
			b.drawButton(g2D);
		}
		for(int counter = 0; counter < 50; counter++){
			int x = levelButtons[counter].getRect().x;
			int y = levelButtons[counter].getRect().y;
			g2D.setFont(new Font("sansserif", Font.BOLD, 16));
			if(levelButtons[counter].getRect().contains(mouseX, mouseY) && !optionsShown){
				g2D.setFont(new Font("sansserif", Font.BOLD, 17));
			}
			if(!custom && !TankMazeRunner.unlocked[counter + 1]){
				g2D.setColor(Color.RED);
				g2D.drawString("LOCKED", x + 50 - (int)(g2D.getFontMetrics().getStringBounds("LOCKED", g2D).getWidth() / 2), y + 85);
			}else if(!custom){
				g2D.setColor(Color.GREEN);
				g2D.drawString("UNLOCKED", x + 50 - (int)(g2D.getFontMetrics().getStringBounds("UNLOCKED", g2D).getWidth() / 2), y + 85);
			}else{
				String fileName = getFileName(counter + 1);
				if(fileName != null && getStringBounds(fileName).getWidth() >= 100){
					g2D.setFont(new Font("sansserif", Font.BOLD, 11));
				}
				g2D.setColor(Color.GREEN);
				if(fileName == null){
					g2D.setColor(Color.RED);
					fileName = "[EMPTY]";
				}	
				g2D.drawString(fileName, x + 50 - (int)(g2D.getFontMetrics().getStringBounds(fileName, g2D).getWidth() / 2), y + 85);
				g2D.setFont(new Font("sansserif", Font.BOLD, 17));
			}
		}
		if(optionsShown){
			showOptions();
		}
		addMouseMotionListener(new BoxListener());
		addMouseListener(new BoxListener());
	}
	public void drawCenteredString(String s, int y){
		int pos = (1280 / 2) - ((int)g2D.getFontMetrics().getStringBounds(s, g2D).getWidth() / 2);
		g2D.drawString(s, pos, y);
	}
	
	private class BoxListener extends MouseAdapter implements MouseMotionListener{
		private Point lastMousePoint = null;
		public void mouseMoved(MouseEvent e){
			lastMousePoint = new Point(mouseX, mouseY);
			mouseY = (int)(e.getY() * invScaleY);
			mouseX = (int)(e.getX() * invScaleX);
			Point mousePoint = new Point(mouseX, mouseY);
			for(Button b: Button.buttons){
				if(b.getRect().contains(mousePoint) && !optionsShown){
					b.hover();
					if(lastMousePoint != null && !b.getRect().contains(lastMousePoint) && b.isActive()){
						Sounds.playSound(Sounds.menuTick);
					}
				}else{
					b.idle();
				}
			}
			e.consume();
			repaint();
		}
		public void mousePressed(MouseEvent e){
			if(!e.isMetaDown() && !e.isConsumed()){
				if(mainMenu.getRect().contains(mouseX, mouseY)){
					mainMenu.click();
				}
				for(int i = 0; i < 50; i++){
					if(levelButtons[i].getRect().contains(mouseX, mouseY) && !optionsShown){
						if(!custom){
							if(TankMazeRunner.unlocked[i + 1]){
								Level.levelNumber = i + 1;
								Level.isCustom = false;
								TankMazeRunner.startGame();
							}
						}else{
							File levelFile = new File("Data/Saves/CustomLevel" + (i + 1) + ".txt");
							if(levelFile.exists()){
								slot = i + 1;
								optionsShown = true;
							}else{
								Level.levelNumber = i + 1;
								Level.isCustom = true;
								TankMazeRunner.showLevelCustomizer();
							}
						}
					}
				}	
				if(optionsShown){
					if(cancel.contains(mouseX, mouseY)){
						optionsShown = false;
					}
					if(play.contains(mouseX, mouseY)){
						optionsShown = false;
						Level.levelNumber = slot;
						Level.isCustom = true;
						TankMazeRunner.startGame();
					}
					if(delete.contains(mouseX, mouseY)){
						optionsShown = false;
						File levelFile = new File("Data/Saves/CustomLevel" + slot + ".txt");
						levelFile.delete();
					}
					if(edit.contains(mouseX, mouseY)){
						optionsShown = false;
						Level.levelNumber = slot;
						Level.isCustom = true;
						TankMazeRunner.showLevelCustomizer();
					}
				}
			}
			e.consume();
			repaint();
		}
	}
	public Rectangle2D getStringBounds(String s){
		return g2D.getFontMetrics().getStringBounds(s, g2D);
	}
	public void showOptions(){
		g2D.setColor(new Color(255, 255, 255, 200));
		g2D.fillRect(1280 / 2 - 250, 720 / 2 - 150, 500, 200);
		
		g2D.setColor(new Color(0, 0, 0, 200));
		g2D.fillRect(1280 / 2 - 250 + 5, 720 / 2 - 150 + 5, 500 - 10, 200 - 10);
		g2D.setColor(new Color(0, 0, 0, 80));
		g2D.fillRect(1280 / 2 - 225,  720 / 2 - 14 - 52, 450, 20);
		g2D.setFont(new Font("sansserif", Font.BOLD, 32));
		g2D.setColor(Color.WHITE);
		drawCenteredString("What would you like to do?", 720 / 2 - 100);
		g2D.setFont(new Font("sansserif", Font.BOLD, 16));
		drawCenteredString("Level: " + getFileName(slot) + " (Slot: " + slot + ")", 720 / 2 - 50);
		drawButton(edit, "Edit Level");
		drawButton(play, "Play Level");
		drawButton(delete, "Delete Level");
		drawButton(cancel, "Cancel");
	}
	public void drawButton(Rectangle rect, String text){
		g2D.setFont(new Font("sansserif", Font.BOLD, 14));
		if(rect.contains(mouseX, mouseY)){
			g2D.setColor(new Color(255, 255, 255, 90));
			g2D.fill(rect);
			drawSelectionBox(rect);
		}else{
			g2D.setColor(new Color(0, 0, 0, 80));
			g2D.fill(rect);
		}
		g2D.setColor(Color.WHITE);
		g2D.drawString(text, (int)((rect.x + (rect.width / 2.0)) - (getStringBounds(text).getWidth() / 2)), (int)((rect.y + (rect.height / 2.0) + getStringBounds(text).getHeight() / 4.0)));
	}
	public void drawSelectionBox(Rectangle rect){
		g2D.setColor(Color.WHITE);
		g2D.fillRect(rect.x - 5, rect.y - 5, rect.width + 10, 5);
		g2D.fillRect(rect.x - 5, rect.y - 5, 5, rect.height + 10);
		g2D.fillRect(rect.x + rect.width, rect.y - 5, 5, rect.height + 10);
		g2D.fillRect(rect.x - 5, rect.y + rect.height, rect.width + 10, 5);
	}
	public String getFileName(int slot){
		Scanner fileReader;
		String fileName = "Untitled";
		try {
			fileReader = new Scanner(new File("Data/Saves/CustomLevel" + slot + ".txt"));
			while(fileReader.hasNextLine()){
				String nextLine = fileReader.nextLine();
				if(nextLine.startsWith("NAME: ")){
					if(nextLine.length() > 15)
						fileName = nextLine.substring(6, 15);
					else
						fileName = nextLine.substring(6);
					fileName = fileName.trim();
					if(fileName.equals("")){
						fileName = "Untitled";
					}
				}
			}
			fileReader.close();
			return fileName;
		} catch (FileNotFoundException e) {
			return null;
		}
		
	}
	public void performAction(Button b) {
		if(b.equals(mainMenu)){
			TankMazeRunner.showMainMenu();	
		}
	}
}
