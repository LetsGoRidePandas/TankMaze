import java.awt.*;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;

public abstract class Tank implements Selectable{
	public static ArrayList<Tank> tanks;
	protected int health;
	protected double direction, speed, gunDirection, x, y;
	protected Color tankColor = Color.GREEN, gunColor = new Color(0, 100, 0), lineColor = Color.RED;
	protected Shape tankBody = new Rectangle((int)(x - 25), (int)(y - 37.5), 50, 75);
	protected char movement = ' ';
	protected char turning = ' ';
	protected AffineTransform transformer = new AffineTransform();
	protected Bullet bullet;
	
	public Tank(int xPosition, int yPosition){
		x = xPosition;
		y = yPosition;
		health = 100;
		direction = 0;
		gunDirection = 0;
		setColors(tankColor, gunColor, lineColor);
	}
	public Tank(int xPosition, int yPosition, double d){
		x = xPosition;
		y = yPosition;
		health = 100;
		direction = d;
		gunDirection = 0;
		setColors(tankColor, gunColor, lineColor);
	}
	public void spawn(Graphics2D g2D){
		g2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		double targetX, targetY;
		if(TankMazeGame.isRunning){
			targetX = getTarget(g2D).x;
			targetY = getTarget(g2D).y;
		}else{
			targetX = x;
			targetY = y;
		}
		if(!bullet.isFired()){
			bullet = new Bullet(x, y, targetX, targetY);
		}
		if(bullet.isFired()){
			bullet.drawBullet(g2D);
			bullet.move();
		}
		g2D.setColor(tankColor);
		//Orients the tank and draws it
		transformer.rotate(Math.toRadians(direction + 90), x, y);
		tankBody = new Rectangle((int)x - 25, (int)(y - 37.5), 50, 75);
		tankBody = transformer.createTransformedShape(tankBody);
		g2D.fill(tankBody);
		transformer.rotate(Math.toRadians(-direction - 90), x, y);
		g2D.rotate(Math.toRadians(direction + 90), x, y);
		Image tankOverlay = getOverlay();
		g2D.drawImage(tankOverlay, (int)(x - 25), (int)(y - 37.5), null);
		g2D.rotate(Math.toRadians(-direction - 90), x, y);
		if(targetX - x != 0)
			gunDirection = Math.atan((targetY - y) / (targetX - x));
		else{
			if(targetY < y)
				gunDirection = Math.toRadians(90);
			else
				gunDirection = Math.toRadians(270);
		}
		if(targetX > x && !TankMazeGame.paused)
			g2D.rotate(gunDirection - Math.toRadians(90), x, y);
		else if(!TankMazeGame.paused)
			g2D.rotate(gunDirection + Math.toRadians(90), x, y);
		g2D.setColor(gunColor);
		g2D.fillRect((int)x - 5, (int)y, 10, 30);
		g2D.fillOval((int)x - 16, (int)y - 16, 32, 32);
		g2D.drawImage(ImageLoader.gun, (int)x - 25, (int)(y - 37.5), null);
		if(targetX > x && !TankMazeGame.paused)
			g2D.rotate(-gunDirection + Math.toRadians(90), x, y);
		else if(!TankMazeGame.paused)
			g2D.rotate(-gunDirection - Math.toRadians(90), x, y);
		for(int i = 0; i < tanks.size(); i++){
			if(tanks.get(i) != this && tankBody.contains(tanks.get(i).getBulletPosition()) && Tank.tanks.get(i).getBullet().isFired()){
				health -= 10;
				tanks.get(i).getBullet().setFired(false);
				Sounds.playSound(Sounds.tankHit);
			}
		}
		if(this instanceof CPUTank){
			g2D.setColor(Color.WHITE);
			g2D.setFont(new Font("sansserif", Font.BOLD, 18));
			g2D.drawString("HP: " + health, (int)(x - g2D.getFontMetrics().getStringBounds("HP: " + health, g2D).getWidth() / 2), (int)(y + (g2D.getFontMetrics().getStringBounds("HP: " + health, g2D).getHeight() / 2)));
		}
		g2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
	}
	public Image getOverlay(){
		return ImageLoader.tank[0];
	}
	public abstract void fire(Graphics2D g2D);
	public abstract Point getTarget(Graphics2D g2D);
	//write in both classes. Controlled tank's is in this class's spawn method and must be moved.
	
	public void setColors(Color t, Color g, Color l) {
		tankColor = t;
		gunColor = g;
		lineColor = l;
	}
	public void setX(int newX){
		x = newX;
	}
	public void setY(int newY){
		y = newY;
	}
	public int getX(){
		return (int)x;
	}
	public int getY(){
		return (int)y;
	}
	public Shape getTankBody(){
		return tankBody;
	}
	public void setHealth(int newHealth){
		health = newHealth;
	}
	public int getHealth(){
		return health;
	}
	public Point getBulletPosition(){
		return new Point((int)bullet.getX(), (int)bullet.getY());
	}
	public Bullet getBullet(){
		return bullet;
	}
	public boolean isMoving(){
		if(movement != ' ' || turning != ' ')
			return true;
		else
			return false;
	}
	public double getDirection(){
		return direction;
	}
	public Rectangle getObjectBounds(){
		return tankBody.getBounds();
	}
	public Color[] getColors(){
		Color[] colors = {tankColor, gunColor, lineColor};
		return colors;
	}
}
