import java.awt.*;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;

public class Wall implements Selectable{
	public static ArrayList<Wall> walls;
	private boolean breakable;
	private boolean broken = false;
	public Rectangle wall;
	private int x, y, width, height;
	private Color wallColor = Color.WHITE;
	
	public Wall(int newX, int newY, int newWidth, int newHeight){
		x = newX;
		y = newY; 
		width = newWidth;
		height = newHeight;
		walls.add(this);
	}
	public void spawn(Graphics2D g2D){
		if(!broken){
			g2D.setColor(wallColor);
			g2D.fillRect(x, y, width, height);
			wall = new Rectangle(x, y, width, height);
			for(int i = 0; i < Tank.tanks.size(); i++){
				Tank tank = Tank.tanks.get(i);
				
				AffineTransform transformer = new AffineTransform();
				Shape hitBox = new Rectangle((int)tank.getX() - 25, (int)(tank.getY() - 37.5), 50, 75);
				transformer.rotate(Math.toRadians(tank.getDirection() + 90), tank.getX(), tank.getY());
				hitBox = transformer.createTransformedShape(hitBox);
				
				if(wall.contains(tank.getBulletPosition())){
					if(breakable && tank instanceof ControlledTank && tank.getBullet().isFired()){
						broken = true;
					}
					tank.getBullet().setFired(false);
				}
			}
		}
	}
	public void setBreakable(boolean newBreakable){
		breakable = newBreakable;
	}
	public void setColor(Color newColor){
		wallColor = newColor;
	}
	public boolean isBroken(){
		return broken;
	}
	public void setBounds(int newX, int newY, int newWidth, int newHeight){
		x = newX;
		y = newY;
		width = newWidth;
		height = newHeight;
	}
	public boolean isBreakable(){
		return breakable;
	}
	public Rectangle getObjectBounds() {
		return wall;
	}
	public int getX(){
		return x;
	}
	public int getY(){
		return y;
	}
	public int getWidth(){
		return width;
	}
	public int getHeight(){
		return height;
	}
	public void setX(int newX) {
		x = newX;	
	}
	public void setY(int newY) {
		y = newY;
	}
	public void setWidth(int width2) {
		width = width2;
	}
	public void setHeight(int height2) {
		height = height2;
	}
}