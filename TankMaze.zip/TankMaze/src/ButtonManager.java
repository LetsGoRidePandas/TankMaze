
public interface ButtonManager{
	public void performAction(Button b);
}
