import java.awt.*;
public class Explosion {
	private int frame = 0;
	private int x, y;

	public Explosion(int xPosition, int yPosition){
		x = xPosition; y = yPosition;
		Sounds.playSound(Sounds.explosion);
	}
	public void spawn(Graphics2D g2D){
		g2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2D.drawImage(ImageLoader.explosion[frame], x - 150, y - 150, null);
		frame++;
		if(frame > 23){
			TankMazeGame.explosions.remove(this);
		}
		g2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
	}
}
